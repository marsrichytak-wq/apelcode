"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ArrowRight, UserRoundCheck } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { offerCities, offerSpheres } from "@/lib/data";
import { useSession } from "@/components/session-provider";

const registerSchema = z.object({
  name: z.string().trim().min(2, "Укажите имя"),
  businessName: z.string().trim().min(2, "Укажите название бизнеса"),
  email: z.string().trim().email("Укажите корректный email"),
  sphere: z.string().trim().min(1, "Выберите сферу"),
  city: z.string().trim().min(1, "Выберите город"),
  reach: z.string().trim().min(2, "Укажите охваты"),
  offering: z.string().trim().min(10, "Опишите подробнее, что предлагаете"),
  lookingFor: z.string().trim().max(200).optional(),
  contacts: z.string().trim().max(200).optional(),
});

type RegisterValues = z.infer<typeof registerSchema>;

type FieldErrors = Partial<Record<keyof RegisterValues, string>>;

const initialValues: RegisterValues = {
  name: "",
  businessName: "",
  email: "",
  sphere: "",
  city: "",
  reach: "",
  offering: "",
  lookingFor: "",
  contacts: "",
};

export function RegisterForm() {
  const router = useRouter();
  const { isRegistered, register } = useSession();
  const [values, setValues] = useState<RegisterValues>(initialValues);
  const [errors, setErrors] = useState<FieldErrors>({});

  const setField = <K extends keyof RegisterValues>(
    key: K,
    value: RegisterValues[K]
  ) => {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = registerSchema.safeParse(values);
    if (!result.success) {
      const nextErrors: FieldErrors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof RegisterValues;
        if (!nextErrors[key]) nextErrors[key] = issue.message;
      }
      setErrors(nextErrors);
      return;
    }
    register(result.data);
    toast.success("Профиль создан. Добро пожаловать в АпельКод!");
    router.push("/profile");
  };

  if (isRegistered) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center gap-4 rounded-xl border border-border bg-card p-8 text-center">
        <span className="flex size-12 items-center justify-center rounded-full bg-primary/15 text-primary">
          <UserRoundCheck className="size-6" aria-hidden />
        </span>
        <p className="text-lg font-semibold">Вы уже зарегистрированы</p>
        <p className="text-sm text-muted-foreground">
          Ваш профиль и личный кабинет доступны по ссылке ниже.
        </p>
        <Link
          href="/profile"
          className="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          Перейти в личный кабинет
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="register-name">Имя</Label>
          <Input
            id="register-name"
            placeholder="Анна"
            value={values.name}
            onChange={(event) => setField("name", event.target.value)}
            aria-invalid={Boolean(errors.name)}
            autoComplete="name"
          />
          {errors.name && (
            <p className="text-xs text-destructive">{errors.name}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="register-business">Название бизнеса</Label>
          <Input
            id="register-business"
            placeholder="Кофейня «Апельсин»"
            value={values.businessName}
            onChange={(event) => setField("businessName", event.target.value)}
            aria-invalid={Boolean(errors.businessName)}
            autoComplete="organization"
          />
          {errors.businessName && (
            <p className="text-xs text-destructive">{errors.businessName}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="register-email">Email</Label>
        <Input
          id="register-email"
          type="email"
          placeholder="you@example.ru"
          value={values.email}
          onChange={(event) => setField("email", event.target.value)}
          aria-invalid={Boolean(errors.email)}
          autoComplete="email"
        />
        {errors.email && (
          <p className="text-xs text-destructive">{errors.email}</p>
        )}
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="space-y-2">
          <Label>Сфера</Label>
          <Select
            value={values.sphere}
            onValueChange={(value) => setField("sphere", value ?? "")}
          >
            <SelectTrigger aria-label="Сфера" className="w-full">
              <SelectValue placeholder="Выберите сферу" />
            </SelectTrigger>
            <SelectContent>
              {offerSpheres.map((item) => (
                <SelectItem key={item} value={item}>
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.sphere && (
            <p className="text-xs text-destructive">{errors.sphere}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label>Город</Label>
          <Select
            value={values.city}
            onValueChange={(value) => setField("city", value ?? "")}
          >
            <SelectTrigger aria-label="Город" className="w-full">
              <SelectValue placeholder="Выберите город" />
            </SelectTrigger>
            <SelectContent>
              {offerCities.map((item) => (
                <SelectItem key={item} value={item}>
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.city && (
            <p className="text-xs text-destructive">{errors.city}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="register-reach">Охваты</Label>
        <Input
          id="register-reach"
          placeholder="18 400 подписчиков"
          value={values.reach}
          onChange={(event) => setField("reach", event.target.value)}
          aria-invalid={Boolean(errors.reach)}
        />
        {errors.reach && (
          <p className="text-xs text-destructive">{errors.reach}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="register-offering">Что предлагаете</Label>
        <Textarea
          id="register-offering"
          rows={4}
          placeholder="Например: обмен постами и сторис с аудиторией, которая ценит specialty-кофе."
          value={values.offering}
          onChange={(event) => setField("offering", event.target.value)}
          aria-invalid={Boolean(errors.offering)}
        />
        {errors.offering && (
          <p className="text-xs text-destructive">{errors.offering}</p>
        )}
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="register-looking-for">
            С кем хотите объединиться
            <span className="font-normal text-muted-foreground">
              {" "}
              (необязательно)
            </span>
          </Label>
          <Input
            id="register-looking-for"
            placeholder="Кофейни, бары, студии красоты"
            value={values.lookingFor}
            onChange={(event) => setField("lookingFor", event.target.value)}
            aria-invalid={Boolean(errors.lookingFor)}
          />
          {errors.lookingFor && (
            <p className="text-xs text-destructive">{errors.lookingFor}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="register-contacts">
            Контакты для визитки
            <span className="font-normal text-muted-foreground">
              {" "}
              (необязательно)
            </span>
          </Label>
          <Input
            id="register-contacts"
            placeholder="Telegram: @name, тел. +7…"
            value={values.contacts}
            onChange={(event) => setField("contacts", event.target.value)}
            aria-invalid={Boolean(errors.contacts)}
          />
          {errors.contacts && (
            <p className="text-xs text-destructive">{errors.contacts}</p>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-3 pt-2 sm:flex-row sm:items-center">
        <Button type="submit" size="lg" className="w-full sm:w-auto">
          Создать аккаунт
          <ArrowRight data-icon="inline-end" aria-hidden />
        </Button>
        <p className="text-sm text-muted-foreground">
          Уже есть аккаунт?{" "}
          <Link
            href="/login"
            className="font-medium text-foreground underline underline-offset-4"
          >
            Войти
          </Link>
        </p>
      </div>
    </form>
  );
}
