"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Handshake, MapPin } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { addDaysUtc, isOverdue, todayUtc } from "@/lib/demo";
import { useSession } from "@/components/session-provider";
import type { Offer } from "@/lib/data";

const dealSchema = z.object({
  title: z.string().trim().min(3, "Укажите название сделки"),
  youDo: z
    .string()
    .trim()
    .min(10, "Опишите, что делаете вы (минимум 10 символов)"),
  partnerDoes: z
    .string()
    .trim()
    .min(10, "Опишите, что делает партнёр (минимум 10 символов)"),
  deadline: z
    .string()
    .min(1, "Укажите срок выполнения")
    .refine((value) => Boolean(value) && !isOverdue(value), {
      message: "Срок не может быть в прошлом",
    }),
});

type DealValues = z.infer<typeof dealSchema>;
type DealErrors = Partial<Record<keyof DealValues, string>>;

interface ProposeDealDialogProps {
  offer: Offer;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProposeDealDialog({
  offer,
  open,
  onOpenChange,
}: ProposeDealDialogProps) {
  const { proposeDeal } = useSession();
  const [values, setValues] = useState<DealValues>(() => ({
    title: `Бартер с ${offer.businessName}`,
    youDo: "",
    partnerDoes: "",
    deadline: addDaysUtc(todayUtc(), 7),
  }));
  const [errors, setErrors] = useState<DealErrors>({});

  const reset = () => {
    setValues({
      title: `Бартер с ${offer.businessName}`,
      youDo: "",
      partnerDoes: "",
      deadline: addDaysUtc(todayUtc(), 7),
    });
    setErrors({});
  };

  const setField = <K extends keyof DealValues>(
    key: K,
    value: DealValues[K]
  ) => {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = dealSchema.safeParse(values);
    if (!result.success) {
      const nextErrors: DealErrors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof DealValues;
        if (!nextErrors[key]) nextErrors[key] = issue.message;
      }
      setErrors(nextErrors);
      return;
    }
    const outcome = proposeDeal({
      partner: offer.businessName,
      ...result.data,
    });
    if (!outcome.ok) {
      toast.error(outcome.reason ?? "Не удалось создать сделку");
      return;
    }
    toast.success(
      "Сделка создана. Условия зафиксированы и видны в личном кабинете."
    );
    onOpenChange(false);
    reset();
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        onOpenChange(next);
        if (!next) reset();
      }}
    >
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Предложить сделку</DialogTitle>
          <DialogDescription>
            Зафиксируйте условия: кто что делает и к какому сроку. Обе стороны
            подтверждают выполнение, после чего сделка закрывается.
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-lg border border-border bg-background/60 p-3">
          <p className="text-sm font-semibold">{offer.businessName}</p>
          <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
            <MapPin className="size-3.5 text-primary" aria-hidden />
            {offer.city} · {offer.sphere}
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="deal-title">Название сделки</Label>
            <Input
              id="deal-title"
              placeholder="Обмен постами в Instagram"
              value={values.title}
              onChange={(event) => setField("title", event.target.value)}
              aria-invalid={Boolean(errors.title)}
            />
            {errors.title && (
              <p className="text-xs text-destructive">{errors.title}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="deal-you-do">Что делаете вы</Label>
            <Textarea
              id="deal-you-do"
              rows={3}
              placeholder="Например: публикуете пост о партнёре в своём аккаунте"
              value={values.youDo}
              onChange={(event) => setField("youDo", event.target.value)}
              aria-invalid={Boolean(errors.youDo)}
            />
            {errors.youDo && (
              <p className="text-xs text-destructive">{errors.youDo}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="deal-partner-does">Что делает партнёр</Label>
            <Textarea
              id="deal-partner-does"
              rows={3}
              placeholder="Например: публикует пост о вас в своём аккаунте"
              value={values.partnerDoes}
              onChange={(event) => setField("partnerDoes", event.target.value)}
              aria-invalid={Boolean(errors.partnerDoes)}
            />
            {errors.partnerDoes && (
              <p className="text-xs text-destructive">{errors.partnerDoes}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="deal-deadline">Срок выполнения</Label>
            <Input
              id="deal-deadline"
              type="date"
              min={todayUtc()}
              value={values.deadline}
              onChange={(event) => setField("deadline", event.target.value)}
              aria-invalid={Boolean(errors.deadline)}
            />
            {errors.deadline && (
              <p className="text-xs text-destructive">{errors.deadline}</p>
            )}
          </div>

          <DialogFooter showCloseButton className="sm:justify-between">
            <Button type="submit">
              <Handshake data-icon="inline-start" aria-hidden />
              Предложить сделку
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
