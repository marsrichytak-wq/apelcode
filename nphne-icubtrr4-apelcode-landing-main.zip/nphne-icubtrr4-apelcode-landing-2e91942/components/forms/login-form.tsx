"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { LogIn } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useSession } from "@/components/session-provider";

const loginSchema = z.object({
  email: z.string().trim().email("Укажите корректный email"),
  businessName: z.string().trim().min(2, "Укажите название бизнеса"),
});

type LoginValues = z.infer<typeof loginSchema>;

type FieldErrors = Partial<Record<keyof LoginValues, string>>;

export function LoginForm() {
  const router = useRouter();
  const { login, isRegistered } = useSession();
  const [values, setValues] = useState<LoginValues>({
    email: "",
    businessName: "",
  });
  const [errors, setErrors] = useState<FieldErrors>({});

  const setField = <K extends keyof LoginValues>(
    key: K,
    value: LoginValues[K]
  ) => {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = loginSchema.safeParse(values);
    if (!result.success) {
      const nextErrors: FieldErrors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof LoginValues;
        if (!nextErrors[key]) nextErrors[key] = issue.message;
      }
      setErrors(nextErrors);
      return;
    }
    login(result.data.email, result.data.businessName);
    toast.success("Вы вошли в демо-аккаунт");
    router.push("/profile");
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-5">
      <div className="space-y-2">
        <Label htmlFor="login-email">Email</Label>
        <Input
          id="login-email"
          type="email"
          placeholder="you@example.ru"
          value={values.email}
          onChange={(event) => setField("email", event.target.value)}
          aria-invalid={Boolean(errors.email)}
          autoComplete="email"
        />
        {errors.email && (
          <p className="text-xs text-destructive">{errors.email}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="login-business">Название бизнеса</Label>
        <Input
          id="login-business"
          placeholder="Кофейня «Апельсин»"
          value={values.businessName}
          onChange={(event) => setField("businessName", event.target.value)}
          aria-invalid={Boolean(errors.businessName)}
          autoComplete="organization"
        />
        {errors.businessName && (
          <p className="text-xs text-destructive">{errors.businessName}</p>
        )}
      </div>

      <div className="flex flex-col gap-3 pt-2 sm:flex-row sm:items-center">
        <Button type="submit" size="lg" className="w-full sm:w-auto">
          <LogIn data-icon="inline-start" aria-hidden />
          Войти
        </Button>
        <p className="text-sm text-muted-foreground">
          Ещё нет аккаунта?{" "}
          <Link
            href="/register"
            className="font-medium text-foreground underline underline-offset-4"
          >
            Зарегистрироваться
          </Link>
        </p>
      </div>

      {isRegistered && (
        <p className="text-xs text-muted-foreground">
          В вашем браузере уже есть профиль. Войдите с тем же email, чтобы
          продолжить работу с ним.
        </p>
      )}
    </form>
  );
}
