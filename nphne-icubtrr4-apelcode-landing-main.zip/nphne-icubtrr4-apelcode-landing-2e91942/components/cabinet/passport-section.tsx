"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Copy, Download, Edit3, IdCard, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useSession } from "@/components/session-provider";
import { buildPublicProfile } from "@/lib/demo";
import { copyText, downloadBusinessCardSvg, passportUrl } from "@/lib/passport";
import { BusinessCardView } from "@/components/passport/business-card-view";
import { ShareLinks } from "@/components/passport/share-links";

export function PassportSection() {
  const { user, updatePassport } = useSession();
  const [editOpen, setEditOpen] = useState(false);
  const [lookingFor, setLookingFor] = useState("");
  const [contacts, setContacts] = useState("");

  if (!user) return null;

  const href = passportUrl(user.publicId);
  const profile = buildPublicProfile(user);

  const handleCopyLink = async () => {
    if (!href) return;
    const ok = await copyText(href);
    if (ok) {
      toast.success("Ссылка на профиль скопирована");
    } else {
      toast.error("Не удалось скопировать ссылку");
    }
  };

  const openEdit = () => {
    setLookingFor(user.profile.lookingFor ?? "");
    setContacts(user.profile.contacts ?? "");
    setEditOpen(true);
  };

  const handleSave = () => {
    const result = updatePassport({ lookingFor, contacts });
    if (!result.ok) {
      toast.error(result.reason ?? "Не удалось сохранить визитку");
      return;
    }
    toast.success(
      "Визитка обновлена — данные изменились и в публичной карточке"
    );
    setEditOpen(false);
  };

  const handleDownload = () => {
    downloadBusinessCardSvg(profile);
    toast.success("Визитка скачана в формате SVG");
  };

  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-center gap-2">
          <IdCard className="size-5 text-primary" aria-hidden />
          <h3 className="text-lg font-semibold">Паспорт партнёра и визитка</h3>
        </div>
        <Button variant="outline" size="sm" onClick={openEdit}>
          <Edit3 data-icon="inline-start" aria-hidden />
          Редактировать визитку
        </Button>
      </div>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Публичная ссылка-карточка профиля и компактная визитка бизнеса, чтобы
        делиться ими вне сайта.
      </p>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div className="flex flex-col gap-3 rounded-lg border border-border bg-background/60 p-4">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Link2 className="size-4 text-primary" aria-hidden />
            Публичная ссылка на профиль
          </div>
          <div className="flex gap-2">
            <Input
              value={href}
              readOnly
              aria-label="Публичная ссылка на профиль"
              className="min-w-0 flex-1"
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={handleCopyLink}
              disabled={!href}
              title="Копировать ссылку"
              aria-label="Копировать ссылку"
            >
              <Copy className="size-4" aria-hidden />
            </Button>
          </div>
          <ShareLinks url={href} />
        </div>

        <div className="flex flex-col gap-3 rounded-lg border border-border bg-background/60 p-4">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <IdCard className="size-4 text-primary" aria-hidden />
            Визитка бизнеса
          </div>
          <BusinessCardView profile={profile} />
          <Button type="button" onClick={handleDownload}>
            <Download data-icon="inline-start" aria-hidden />
            Скачать визитку (SVG)
          </Button>
        </div>
      </div>

      <Dialog
        open={editOpen}
        onOpenChange={(open) => {
          setEditOpen(open);
          if (!open) {
            setLookingFor(user.profile.lookingFor ?? "");
            setContacts(user.profile.contacts ?? "");
          }
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Редактировать визитку</DialogTitle>
            <DialogDescription>
              Данные появятся в публичной карточке профиля и в визитке бизнеса.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              handleSave();
            }}
            noValidate
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="passport-looking-for">
                С кем хотите объединиться
              </Label>
              <Textarea
                id="passport-looking-for"
                rows={2}
                placeholder="Кофейни, бары, студии красоты…"
                value={lookingFor}
                onChange={(event) => setLookingFor(event.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="passport-contacts">Контакты для визитки</Label>
              <Textarea
                id="passport-contacts"
                rows={2}
                placeholder="Telegram: @name, тел. +7…"
                value={contacts}
                onChange={(event) => setContacts(event.target.value)}
              />
            </div>
            <DialogFooter showCloseButton className="sm:justify-between">
              <Button type="submit">Сохранить</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
