"use client";

import Link from "next/link";
import {
  Activity,
  Building2,
  LogIn,
  LogOut,
  MapPin,
  Sparkles,
  UserPlus,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useSession } from "@/components/session-provider";
import { StatsCards } from "./stats-cards";
import { DealsList } from "./deals-list";
import { DealCalendar } from "./deal-calendar";
import { MyOffers, OfferFormDialog } from "./offer-form";
import { PassportSection } from "./passport-section";

export function ProfileCabinet() {
  const { user } = useSession();

  if (!user) return <EmptyCabinet />;

  const initials = user.profile.businessName.trim().charAt(0) || "А";

  return (
    <section aria-label="Личный кабинет">
      <div className="container mx-auto space-y-8 px-4 py-12 sm:py-16">
        <div className="flex flex-col gap-4 rounded-xl border border-border bg-card p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <span className="flex size-14 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-xl font-bold text-primary">
              {initials}
            </span>
            <div>
              <h2 className="text-xl font-semibold tracking-tight">
                {user.profile.businessName}
              </h2>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {user.profile.name.trim() ? `${user.profile.name} · ` : ""}
                {user.profile.email}
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge variant="outline">
                  <MapPin data-icon="inline-start" aria-hidden />
                  {user.profile.city}
                </Badge>
                <Badge variant="outline">
                  <Sparkles data-icon="inline-start" aria-hidden />
                  {user.profile.sphere}
                </Badge>
                <Badge variant="outline">
                  <Activity data-icon="inline-start" aria-hidden />
                  Охват: {user.profile.reach}
                </Badge>
              </div>
            </div>
          </div>
          <LogoutButton />
        </div>

        <StatsCards />

        <PassportSection />

        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg font-semibold">Ваше предложение</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Опубликуйте карточку в каталоге и найдите партнёра.
            </p>
          </div>
          <OfferFormDialog />
        </div>

        <MyOffers />

        <div className="grid gap-5 lg:grid-cols-2">
          <DealsList deals={user.deals} />
          <DealCalendar deals={user.deals} />
        </div>
      </div>
    </section>
  );
}

function LogoutButton() {
  const { logout } = useSession();
  return (
    <Button
      variant="outline"
      onClick={() => {
        logout();
      }}
    >
      <LogOut data-icon="inline-start" aria-hidden />
      Выйти
    </Button>
  );
}

function EmptyCabinet() {
  return (
    <section aria-label="Личный кабинет">
      <div className="container mx-auto px-4 py-24">
        <div className="mx-auto flex max-w-md flex-col items-center gap-4 rounded-xl border border-border bg-card p-10 text-center">
          <span className="flex size-14 items-center justify-center rounded-full bg-muted text-muted-foreground">
            <Building2 className="size-7" aria-hidden />
          </span>
          <h2 className="text-xl font-semibold tracking-tight">
            Вы ещё не вошли
          </h2>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Войдите или зарегистрируйтесь, чтобы увидеть рейтинг доверия, баланс
            долек, квоту предложений и свои сделки.
          </p>
          <div className="mt-2 flex w-full flex-col gap-2 sm:flex-row sm:justify-center">
            <Link
              href="/login"
              className="inline-flex h-10 w-full items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground sm:w-auto"
            >
              <LogIn data-icon="inline-start" aria-hidden />
              Войти
            </Link>
            <Link
              href="/register"
              className="inline-flex h-10 w-full items-center justify-center rounded-lg border border-border bg-background px-4 text-sm font-medium sm:w-auto"
            >
              <UserPlus data-icon="inline-start" aria-hidden />
              Зарегистрироваться
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
