"use client";

import { toast } from "sonner";
import { Coins, ShieldCheck, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { QUOTA_EXPAND_COST, QUOTA_EXPANDED, trustPercent } from "@/lib/demo";
import { useSession } from "@/components/session-provider";

export function StatsCards() {
  const { user, expandQuota } = useSession();

  if (!user) return null;

  const percent = trustPercent(user);
  const quotaProgress = Math.round(
    (user.publishedThisWeek / user.quotaLimit) * 100
  );

  const handleExpand = () => {
    const result = expandQuota();
    if (result.ok) {
      toast.success(
        `Квота расширена до ${QUOTA_EXPANDED} предложений в неделю`
      );
    } else {
      toast.error(result.reason ?? "Не удалось расширить квоту");
    }
  };

  return (
    <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <ShieldCheck className="size-4.5" aria-hidden />
          </span>
          Рейтинг доверия
        </div>
        <p className="mt-4 text-3xl font-bold tracking-tight">{percent}%</p>
        <p className="mt-1 text-sm text-muted-foreground">
          Выполнил {user.trustCompleted} из {user.trustTotal} сделок — {percent}
          %
        </p>
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <Coins className="size-4.5" aria-hidden />
          </span>
          Баланс долек
        </div>
        <p className="mt-4 text-3xl font-bold tracking-tight">
          {user.balance}{" "}
          <span className="text-base font-medium text-muted-foreground">
            долек
          </span>
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Внутренняя валюта платформы. Накопятся за подтверждённые сделки.
        </p>
      </div>

      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <TrendingUp className="size-4.5" aria-hidden />
          </span>
          Квота предложений
        </div>
        <p className="mt-4 text-sm">
          Опубликовано{" "}
          <span className="text-2xl font-bold tracking-tight">
            {user.publishedThisWeek}
          </span>{" "}
          из {user.quotaLimit} на этой неделе
        </p>
        <div
          className="mt-3 h-2 overflow-hidden rounded-full bg-muted"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={user.quotaLimit}
          aria-valuenow={user.publishedThisWeek}
        >
          <div
            className="h-full rounded-full bg-primary transition-all duration-300"
            style={{ width: `${Math.min(100, quotaProgress)}%` }}
          />
        </div>
        {user.quotaExpanded ? (
          <p className="mt-3 text-xs text-muted-foreground">
            Квота расширена до {QUOTA_EXPANDED} предложений в неделю.
          </p>
        ) : (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              Новичок — 3 в неделю. Расширьте до {QUOTA_EXPANDED}.
            </p>
            <Button
              variant="outline"
              size="sm"
              disabled={user.balance < QUOTA_EXPAND_COST}
              onClick={handleExpand}
            >
              Расширить за {QUOTA_EXPAND_COST} долек
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
