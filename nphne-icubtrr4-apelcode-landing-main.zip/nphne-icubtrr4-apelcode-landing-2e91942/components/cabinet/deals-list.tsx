"use client";

import { toast } from "sonner";
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  CircleDashed,
  Clock3,
  Handshake,
  ShieldCheck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { daysUntil, formatDate, isOverdue, type DemoDeal } from "@/lib/demo";
import { useSession } from "@/components/session-provider";

function ConfirmationRow({
  label,
  confirmed,
  date,
}: {
  label: string;
  confirmed: boolean;
  date?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1",
        confirmed
          ? "border-primary/40 bg-primary/10 text-primary"
          : "border-border bg-background/40 text-muted-foreground"
      )}
    >
      {confirmed ? (
        <CheckCircle2 className="size-3.5" aria-hidden />
      ) : (
        <CircleDashed className="size-3.5" aria-hidden />
      )}
      {label}:{" "}
      {confirmed ? `подтверждено${date ? ` ${date}` : ""}` : "не подтверждено"}
    </span>
  );
}

export function DealsList({ deals }: { deals: DemoDeal[] }) {
  const { confirmDeal, confirmDealAsPartner } = useSession();

  const sorted = [...deals].sort((a, b) => {
    if (a.status === "completed" && b.status !== "completed") return 1;
    if (a.status !== "completed" && b.status === "completed") return -1;
    return a.deadline.localeCompare(b.deadline);
  });

  const handleMyConfirm = (id: string) => {
    const result = confirmDeal(id);
    if (!result.ok) {
      toast.error(result.reason ?? "Не удалось подтвердить выполнение");
      return;
    }
    toast.success(
      result.completed
        ? "Сделка закрыта — обе стороны подтвердили выполнение."
        : "Вы подтвердили выполнение своей части."
    );
  };

  const handlePartnerConfirm = (id: string) => {
    const result = confirmDealAsPartner(id);
    if (!result.ok) {
      toast.error(result.reason ?? "Не удалось подтвердить выполнение");
      return;
    }
    toast.success(
      result.completed
        ? "Сделка закрыта — обе стороны подтвердили выполнение."
        : "Партнёр подтвердил выполнение своей части."
    );
  };

  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center gap-2">
        <CalendarClock className="size-4 text-primary" aria-hidden />
        <h3 className="text-base font-semibold">Мои сделки</h3>
        <Badge variant="secondary" className="ml-auto">
          {deals.length}
        </Badge>
      </div>

      <ul className="mt-4 space-y-3">
        {sorted.map((deal) => {
          const completed = deal.status === "completed";
          const overdue = !completed && isOverdue(deal.deadline);
          const remaining = daysUntil(deal.deadline);
          const waitingForMe = !deal.myConfirmed;
          const waitingForPartner = !deal.partnerConfirmed;

          return (
            <li
              key={deal.id}
              className="rounded-lg border border-border bg-background/60 p-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold">{deal.title}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Партнёр: {deal.partner}
                  </p>
                </div>
                {completed ? (
                  <Badge variant="secondary">Закрыта</Badge>
                ) : overdue ? (
                  <Badge variant="destructive">Просрочено</Badge>
                ) : (
                  <Badge variant="outline">Активна</Badge>
                )}
              </div>

              <div className="mt-3 space-y-1.5">
                <div className="rounded-lg bg-background/40 px-3 py-2">
                  <p className="text-xs font-semibold text-foreground">
                    Вы делаете
                  </p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                    {deal.youDo}
                  </p>
                </div>
                <div className="rounded-lg bg-background/40 px-3 py-2">
                  <p className="text-xs font-semibold text-foreground">
                    Партнёр делает
                  </p>
                  <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                    {deal.partnerDoes}
                  </p>
                </div>
              </div>

              <div className="mt-3 flex items-center gap-2 text-xs">
                {completed ? (
                  <>
                    <Clock3 className="size-3.5 text-primary" aria-hidden />
                    <span className="text-muted-foreground">
                      Срок был:{" "}
                      <span className="font-medium text-foreground">
                        {formatDate(deal.deadline)}
                      </span>
                    </span>
                  </>
                ) : overdue ? (
                  <>
                    <AlertTriangle
                      className="size-3.5 text-destructive"
                      aria-hidden
                    />
                    <span className="text-destructive">
                      Дедлайн был {formatDate(deal.deadline)} — просрочено на{" "}
                      {Math.abs(remaining)} дн.
                    </span>
                  </>
                ) : remaining === 0 ? (
                  <>
                    <Clock3 className="size-3.5 text-primary" aria-hidden />
                    <span className="font-medium text-primary">
                      Дедлайн сегодня — {formatDate(deal.deadline)}
                    </span>
                  </>
                ) : (
                  <>
                    <Clock3 className="size-3.5 text-primary" aria-hidden />
                    <span className="text-muted-foreground">
                      Дедлайн:{" "}
                      <span className="font-medium text-foreground">
                        {formatDate(deal.deadline)}
                      </span>{" "}
                      · осталось {remaining} дн.
                    </span>
                  </>
                )}
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                <ConfirmationRow
                  label="Вы"
                  confirmed={deal.myConfirmed}
                  date={
                    deal.myConfirmedAt
                      ? formatDate(deal.myConfirmedAt)
                      : undefined
                  }
                />
                <ConfirmationRow
                  label="Партнёр"
                  confirmed={deal.partnerConfirmed}
                  date={
                    deal.partnerConfirmedAt
                      ? formatDate(deal.partnerConfirmedAt)
                      : undefined
                  }
                />
              </div>

              {completed ? (
                <p className="mt-3 flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-xs text-primary">
                  <ShieldCheck className="size-3.5 shrink-0" aria-hidden />
                  Сделка закрыта — обе стороны подтвердили выполнение.
                </p>
              ) : (
                <>
                  <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                    <Button
                      type="button"
                      size="sm"
                      className="w-full sm:w-auto"
                      disabled={!waitingForMe}
                      onClick={() => handleMyConfirm(deal.id)}
                    >
                      <CheckCircle2 data-icon="inline-start" aria-hidden />
                      {deal.myConfirmed ? "Вы выполнили" : "Выполнено"}
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="w-full sm:w-auto"
                      disabled={!waitingForPartner}
                      onClick={() => handlePartnerConfirm(deal.id)}
                    >
                      <Handshake data-icon="inline-start" aria-hidden />
                      {deal.partnerConfirmed
                        ? "Партнёр подтвердил"
                        : "Подтвердить за партнёра (демо)"}
                    </Button>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Сделка закроется, когда обе стороны нажмут «Выполнено».
                  </p>
                </>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
