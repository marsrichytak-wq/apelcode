"use client";

import { cn } from "@/lib/utils";
import { formatMonth, isOverdue, todayUtc, type DemoDeal } from "@/lib/demo";

const WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

export function DealCalendar({ deals }: { deals: DemoDeal[] }) {
  const today = todayUtc();
  const [year, month] = today.split("-").map(Number);
  const monthKey = `${year}-${pad(month)}`;
  const firstDayIndex =
    (new Date(Date.UTC(year, month - 1, 1)).getUTCDay() + 6) % 7;
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();

  const deadlinesByDay = new Map<string, DemoDeal[]>();
  for (const deal of deals) {
    if (!deal.deadline.startsWith(monthKey)) continue;
    const list = deadlinesByDay.get(deal.deadline) ?? [];
    list.push(deal);
    deadlinesByDay.set(deal.deadline, list);
  }

  const cells: Array<{ day: number; date: string } | null> = [];
  for (let index = 0; index < firstDayIndex; index += 1) cells.push(null);
  for (let day = 1; day <= daysInMonth; day += 1) {
    cells.push({ day, date: `${monthKey}-${pad(day)}` });
  }

  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-base font-semibold">Календарь дедлайнов</h3>
        <span className="text-sm text-muted-foreground">
          {formatMonth(today)}
        </span>
      </div>

      <div className="mt-4 grid grid-cols-7 gap-1.5 text-center">
        {WEEKDAYS.map((weekday) => (
          <span
            key={weekday}
            className="text-xs font-medium text-muted-foreground"
          >
            {weekday}
          </span>
        ))}
        {cells.map((cell, index) =>
          cell ? (
            <div
              key={cell.date}
              title={
                deadlinesByDay
                  .get(cell.date)
                  ?.map((deal) => deal.title)
                  .join(", ") ?? undefined
              }
              className={cn(
                "relative flex h-10 items-center justify-center rounded-lg text-sm",
                cell.date === today
                  ? "bg-primary/15 font-semibold text-primary ring-1 ring-primary/40"
                  : deadlinesByDay.has(cell.date)
                    ? "bg-background/60 text-foreground"
                    : "text-muted-foreground"
              )}
            >
              {cell.day}
              {deadlinesByDay.has(cell.date) && (
                <span
                  aria-hidden
                  className={cn(
                    "absolute bottom-1.5 h-1.5 w-1.5 rounded-full",
                    deadlinesByDay
                      .get(cell.date)!
                      .some(
                        (deal) =>
                          deal.status !== "completed" &&
                          isOverdue(deal.deadline)
                      )
                      ? "bg-destructive"
                      : "bg-primary"
                  )}
                />
              )}
            </div>
          ) : (
            <div key={`empty-${index}`} aria-hidden />
          )
        )}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="size-1.5 rounded-full bg-primary" aria-hidden />
          активный дедлайн
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-1.5 rounded-full bg-destructive" aria-hidden />
          просроченный
        </span>
      </div>
    </div>
  );
}
