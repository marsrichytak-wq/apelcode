"use client";

import { useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, Megaphone, Plus, Trash2 } from "lucide-react";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useSession } from "@/components/session-provider";

const offerSchema = z.object({
  type: z.enum(["Бартер", "Коллаборация"]),
  description: z
    .string()
    .trim()
    .min(10, "Опишите предложение подробнее (минимум 10 символов)"),
  engagement: z.string().trim().min(1, "Укажите вовлечённость"),
});

type OfferValues = z.infer<typeof offerSchema>;
type OfferErrors = Partial<Record<keyof OfferValues, string>>;

const initialValues: OfferValues = {
  type: "Бартер",
  description: "",
  engagement: "",
};

export function OfferFormDialog() {
  const { publishOffer } = useSession();
  const [open, setOpen] = useState(false);
  const [values, setValues] = useState<OfferValues>(initialValues);
  const [errors, setErrors] = useState<OfferErrors>({});

  const reset = () => {
    setValues(initialValues);
    setErrors({});
  };

  const setField = <K extends keyof OfferValues>(
    key: K,
    value: OfferValues[K]
  ) => {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = offerSchema.safeParse(values);
    if (!result.success) {
      const nextErrors: OfferErrors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof OfferValues;
        if (!nextErrors[key]) nextErrors[key] = issue.message;
      }
      setErrors(nextErrors);
      return;
    }
    const outcome = publishOffer(result.data);
    if (!outcome.ok) {
      toast.error(outcome.reason ?? "Не удалось опубликовать предложение");
      return;
    }
    toast.success("Предложение опубликовано и появилось в каталоге");
    setOpen(false);
    reset();
  };

  return (
    <>
      <Button
        size="lg"
        onClick={() => {
          reset();
          setOpen(true);
        }}
      >
        <Plus data-icon="inline-start" aria-hidden />
        Создать предложение
      </Button>

      <Dialog
        open={open}
        onOpenChange={(next) => {
          setOpen(next);
          if (!next) reset();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Новое предложение</DialogTitle>
            <DialogDescription>
              Предложение появится в каталоге под вашим профилем. Карточка
              использует сферу, город и охваты из профиля.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div className="space-y-2">
              <Label>Тип</Label>
              <Select
                value={values.type}
                onValueChange={(value) => setField("type", value ?? "Бартер")}
              >
                <SelectTrigger aria-label="Тип" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Бартер">Бартер</SelectItem>
                  <SelectItem value="Коллаборация">Коллаборация</SelectItem>
                </SelectContent>
              </Select>
              {errors.type && (
                <p className="text-xs text-destructive">{errors.type}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="offer-description">Описание</Label>
              <Textarea
                id="offer-description"
                rows={4}
                placeholder="Например: обмен постами и сторис с аудиторией, которая ценит качественный кофе."
                value={values.description}
                onChange={(event) =>
                  setField("description", event.target.value)
                }
                aria-invalid={Boolean(errors.description)}
              />
              {errors.description && (
                <p className="text-xs text-destructive">{errors.description}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="offer-engagement">Вовлечённость</Label>
              <Input
                id="offer-engagement"
                placeholder="4.8%"
                value={values.engagement}
                onChange={(event) => setField("engagement", event.target.value)}
                aria-invalid={Boolean(errors.engagement)}
              />
              {errors.engagement && (
                <p className="text-xs text-destructive">{errors.engagement}</p>
              )}
            </div>

            <DialogFooter showCloseButton className="sm:justify-between">
              <Button type="submit">
                <Megaphone data-icon="inline-start" aria-hidden />
                Опубликовать
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function MyOffers() {
  const { user, removeOffer } = useSession();

  if (!user || user.offers.length === 0) return null;

  const handleRemove = (id: string) => {
    removeOffer(id);
    toast.success("Предложение снято с публикации");
  };

  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center gap-2">
        <Megaphone className="size-4 text-primary" aria-hidden />
        <h3 className="text-base font-semibold">Мои предложения</h3>
        <Badge variant="secondary" className="ml-auto">
          {user.offers.length}
        </Badge>
      </div>

      <ul className="mt-4 space-y-3">
        {user.offers.map((offer) => (
          <li
            key={offer.id}
            className="rounded-lg border border-border bg-background/60 p-4"
          >
            <div className="flex items-start justify-between gap-3">
              <Badge
                variant={offer.type === "Бартер" ? "default" : "secondary"}
              >
                {offer.type}
              </Badge>
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <CheckCircle2 className="size-3.5 text-primary" aria-hidden />
                Опубликовано в каталоге
              </span>
            </div>
            <p className="mt-3 text-sm leading-relaxed">{offer.description}</p>
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
              <span>
                Охват: {user.profile.reach} · Вовлечённость: {offer.engagement}
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={() => handleRemove(offer.id)}
              >
                <Trash2 data-icon="inline-start" aria-hidden />
                Снять с публикации
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
