"use client";

import {
  Activity,
  BadgeCheck,
  Handshake,
  Mail,
  MapPin,
  Sparkles,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { PublicProfile } from "@/lib/demo";
import { ShareLinks } from "./share-links";

export function PassportCard({
  profile,
  url,
}: {
  profile: PublicProfile;
  url: string;
}) {
  const initials = profile.businessName.trim().charAt(0) || "А";

  return (
    <article className="mx-auto max-w-xl overflow-hidden rounded-2xl border border-border bg-card">
      <div className="bg-gradient-to-r from-primary/20 to-transparent px-6 py-3 text-xs font-medium text-primary uppercase tracking-wide">
        АпельКод · безопасный бартер и коллаборации
      </div>

      <div className="space-y-6 p-6 sm:p-8">
        <header className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <span className="flex size-16 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-2xl font-bold text-primary">
            {initials}
          </span>
          <div className="min-w-0">
            <h1 className="text-2xl font-bold tracking-tight">
              {profile.businessName}
            </h1>
            <p className="mt-1 truncate text-sm text-muted-foreground">
              {profile.name.trim() ? `${profile.name} · ` : ""}
              {profile.email}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="outline">
                <MapPin data-icon="inline-start" aria-hidden />
                {profile.city}
              </Badge>
              <Badge variant="outline">
                <Sparkles data-icon="inline-start" aria-hidden />
                {profile.sphere}
              </Badge>
              <Badge variant="outline">
                <Activity data-icon="inline-start" aria-hidden />
                Охват: {profile.reach}
              </Badge>
              <Badge variant="secondary">
                <BadgeCheck data-icon="inline-start" aria-hidden />
                Рейтинг доверия: {profile.trustPercent}%
              </Badge>
            </div>
          </div>
        </header>

        <Separator />

        <section aria-label="Что предлагает">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Что предлагает
          </h2>
          <p className="mt-2 text-sm leading-relaxed">{profile.offering}</p>
          {profile.offers.length > 0 && (
            <ul className="mt-4 space-y-2">
              {profile.offers.map((offer, index) => (
                <li
                  key={index}
                  className="rounded-lg border border-border bg-background/60 p-3"
                >
                  <Badge
                    variant={offer.type === "Бартер" ? "default" : "secondary"}
                  >
                    {offer.type}
                  </Badge>
                  <p className="mt-2 text-sm leading-relaxed">
                    {offer.description}
                  </p>
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    Вовлечённость: {offer.engagement}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section aria-label="С кем хочет объединиться">
          <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            <Handshake className="size-4 text-primary" aria-hidden />С кем хочет
            объединиться
          </h2>
          <p className="mt-2 text-sm leading-relaxed">
            {profile.lookingFor.trim() ||
              "Готов к бартеру и коллаборациям с бизнесами из своей сферы и смежных направлений."}
          </p>
        </section>

        <section aria-label="Контакты">
          <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            <Mail className="size-4 text-primary" aria-hidden />
            Контакты
          </h2>
          <dl className="mt-2 grid gap-2 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-medium">{profile.email}</span>
            </div>
            {profile.contacts.trim() && (
              <div>
                <p className="leading-relaxed">{profile.contacts}</p>
              </div>
            )}
          </dl>
        </section>

        <Separator />

        <footer aria-label="Поделиться профилем">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Поделиться профилем
          </h2>
          <ShareLinks url={url} className="mt-3" />
        </footer>
      </div>
    </article>
  );
}
