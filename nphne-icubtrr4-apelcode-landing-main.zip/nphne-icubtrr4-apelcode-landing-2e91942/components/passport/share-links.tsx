"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Check, Copy, MessageCircle, Send, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { copyText } from "@/lib/passport";

const shareTargets = [
  { id: "telegram", label: "Telegram", icon: Send },
  { id: "vk", label: "VK", icon: Share2 },
  { id: "whatsapp", label: "WhatsApp", icon: MessageCircle },
] as const;

type ShareTargetId = (typeof shareTargets)[number]["id"];

const targetLabel = (id: ShareTargetId) =>
  shareTargets.find((target) => target.id === id)?.label ?? "мессенджер";

export function ShareLinks({
  url,
  className,
}: {
  url: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async (target?: ShareTargetId) => {
    const ok = await copyText(url);
    if (!ok) {
      toast.error("Не удалось скопировать ссылку");
      return;
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
    if (target) {
      toast.success(
        `Ссылка скопирована — отправка через ${targetLabel(target)} в демо-режиме заменена копированием`
      );
    } else {
      toast.success("Ссылка скопирована");
    }
  };

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="grid grid-cols-3 gap-2">
        {shareTargets.map((target) => (
          <Button
            key={target.id}
            type="button"
            variant="outline"
            onClick={() => handleCopy(target.id)}
            title={`Отправить через ${target.label}`}
          >
            <target.icon data-icon="inline-start" aria-hidden />
            {target.label}
          </Button>
        ))}
      </div>
      <Button
        type="button"
        className="w-full"
        onClick={() => handleCopy()}
        disabled={!url}
      >
        {copied ? (
          <Check data-icon="inline-start" aria-hidden />
        ) : (
          <Copy data-icon="inline-start" aria-hidden />
        )}
        {copied ? "Ссылка скопирована" : "Копировать ссылку"}
      </Button>
      <p className="text-xs text-muted-foreground">
        Демо-режим: кнопки Telegram, VK и WhatsApp копируют ссылку вместо
        отправки.
      </p>
    </div>
  );
}
