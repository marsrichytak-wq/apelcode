"use client";

import { useMemo } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { UserX } from "lucide-react";
import { buttonVariants } from "@/components/ui/button-variants";
import { cn } from "@/lib/utils";
import {
  buildPublicProfile,
  loadDemoUser,
  loadPublicProfile,
  type PublicProfile,
} from "@/lib/demo";
import { PassportCard } from "./passport-card";

function resolveProfile(publicId: string): PublicProfile | null {
  if (!publicId) return null;
  const found = loadPublicProfile(publicId);
  if (found) return found;
  const session = loadDemoUser();
  if (session?.publicId === publicId) return buildPublicProfile(session);
  return null;
}

export function PassportView() {
  const params = useSearchParams();
  const publicId = params.get("u") ?? "";
  const profile = useMemo(() => resolveProfile(publicId), [publicId]);
  const url = typeof window === "undefined" ? "" : window.location.href;

  if (!profile) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 rounded-2xl border border-border bg-card p-10 text-center">
        <span className="flex size-14 items-center justify-center rounded-full bg-muted text-muted-foreground">
          <UserX className="size-7" aria-hidden />
        </span>
        <h1 className="text-xl font-semibold tracking-tight">
          Профиль не найден
        </h1>
        <p className="text-sm leading-relaxed text-muted-foreground">
          В демо-режиме данные хранятся локально в браузере, поэтому публичная
          карточка доступна с того же устройства, где создан профиль.
        </p>
        <Link href="/" className={cn(buttonVariants())}>
          На главную
        </Link>
      </div>
    );
  }

  return <PassportCard profile={profile} url={url} />;
}
