import type { PublicProfile } from "@/lib/demo";

export function BusinessCardView({ profile }: { profile: PublicProfile }) {
  const initials = profile.businessName.trim().charAt(0) || "А";

  return (
    <div className="relative aspect-[21/10] w-full overflow-hidden rounded-xl border border-border bg-gradient-to-br from-[#241d14] to-[#16120d]">
      <span
        aria-hidden
        className="absolute inset-y-0 left-0 w-1.5 bg-primary"
      />
      <div className="flex h-full flex-col justify-between py-4 pr-5 pl-6">
        <div className="flex items-center gap-3">
          <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">
            {initials}
          </span>
          <div className="min-w-0">
            <p className="truncate text-base font-semibold tracking-tight">
              {profile.businessName}
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {profile.sphere} · {profile.city}
            </p>
          </div>
        </div>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs">
          <div>
            <dt className="text-muted-foreground">Охват</dt>
            <dd className="mt-0.5 truncate font-medium">{profile.reach}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Контакты</dt>
            <dd className="mt-0.5 truncate font-medium">
              {profile.contacts.trim() || profile.email}
            </dd>
          </div>
        </dl>
        <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-primary/70">
          АпельКод · безопасный бартер
        </p>
      </div>
    </div>
  );
}
