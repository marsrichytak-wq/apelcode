"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Coins,
  Image as ImageIcon,
  LayoutDashboard,
  Menu,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import { cn } from "@/lib/utils";
import { useSession } from "@/components/session-provider";

const navLinks = [
  { href: "#catalog", label: "Каталог" },
  { href: "#how-it-works", label: "Как это работает" },
  { href: "#map", label: "Карта сделок" },
  { href: "#reviews", label: "Отзывы" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { user, isRegistered, logout } = useSession();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between gap-4 px-4">
        <Link
          href="/"
          onClick={() => setOpen(false)}
          className="flex items-center gap-3"
        >
          <span
            aria-hidden
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-dashed border-border bg-muted/50 text-muted-foreground"
          >
            <ImageIcon className="h-4 w-4" />
          </span>
          <span className="text-lg font-semibold tracking-tight">АпельКод</span>
        </Link>

        <nav
          aria-label="Основная навигация"
          className="hidden items-center gap-8 md:flex"
        >
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          {isRegistered && user ? (
            <>
              <span
                title="Баланс долек"
                className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground"
              >
                <Coins className="size-3.5 text-primary" aria-hidden />
                {user.balance} долек
              </span>
              <Link
                href="/profile"
                className={cn(buttonVariants({ size: "sm" }))}
              >
                <LayoutDashboard data-icon="inline-start" aria-hidden />
                Личный кабинет
              </Link>
              <Button variant="ghost" size="sm" onClick={logout}>
                Выйти
              </Button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className={cn(buttonVariants({ variant: "ghost", size: "sm" }))}
              >
                Войти
              </Link>
              <Link
                href="/register"
                className={cn(buttonVariants({ size: "sm" }))}
              >
                Регистрация
              </Link>
            </>
          )}
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label="Открыть меню"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </Button>
      </div>

      {open && (
        <div
          id="mobile-menu"
          className="border-t border-border bg-background/95 backdrop-blur-md md:hidden"
        >
          <nav
            aria-label="Мобильная навигация"
            className="container mx-auto flex flex-col gap-1 px-4 py-4"
          >
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-md px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                {link.label}
              </Link>
            ))}
            <div className="my-2 h-px bg-border" />
            <div className="flex flex-col gap-2 px-3 pt-1">
              {isRegistered && user ? (
                <>
                  <Link
                    href="/profile"
                    onClick={() => setOpen(false)}
                    className={cn(buttonVariants({ size: "sm" }), "w-full")}
                  >
                    <LayoutDashboard data-icon="inline-start" aria-hidden />
                    Личный кабинет
                  </Link>
                  <span className="flex items-center justify-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-muted-foreground">
                    <Coins className="size-3.5 text-primary" aria-hidden />
                    {user.balance} долек
                  </span>
                  <Button
                    variant="ghost"
                    className="w-full"
                    onClick={() => {
                      logout();
                      setOpen(false);
                    }}
                  >
                    Выйти
                  </Button>
                </>
              ) : (
                <>
                  <Link
                    href="/login"
                    onClick={() => setOpen(false)}
                    className={cn(
                      buttonVariants({ variant: "ghost" }),
                      "w-full"
                    )}
                  >
                    Войти
                  </Link>
                  <Link
                    href="/register"
                    onClick={() => setOpen(false)}
                    className={cn(buttonVariants(), "w-full")}
                  >
                    Регистрация
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
