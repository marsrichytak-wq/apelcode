"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useSyncExternalStore,
} from "react";
import {
  buildDemoOffer,
  buildProposedDeal,
  clearDemoUser,
  confirmDealSide,
  createDemoUser,
  DEMO_STORAGE_KEY,
  normalizeUser,
  QUOTA_EXPAND_COST,
  QUOTA_EXPANDED,
  saveDemoUser,
  savePublicProfile,
  type DemoUser,
  type ProposeDealInput,
  type RegisterInput,
} from "@/lib/demo";
import type { OfferType } from "@/lib/data";

export interface PublishOfferInput {
  type: OfferType;
  description: string;
  engagement: string;
}

export interface ActionResult {
  ok: boolean;
  reason?: string;
  completed?: boolean;
}

export interface PassportInput {
  lookingFor: string;
  contacts: string;
}

interface SessionContextValue {
  user: DemoUser | null;
  isRegistered: boolean;
  register: (input: RegisterInput) => void;
  login: (email: string, businessName: string) => void;
  logout: () => void;
  publishOffer: (input: PublishOfferInput) => ActionResult;
  expandQuota: () => ActionResult;
  removeOffer: (id: string) => void;
  proposeDeal: (input: ProposeDealInput) => ActionResult;
  confirmDeal: (id: string) => ActionResult;
  confirmDealAsPartner: (id: string) => ActionResult;
  updatePassport: (input: PassportInput) => ActionResult;
}

const SessionContext = createContext<SessionContextValue | null>(null);

let cachedUser: DemoUser | null = null;
let loaded = false;
const listeners = new Set<() => void>();

function emit() {
  for (const listener of listeners) listener();
}

function readFromStorage(): DemoUser | null {
  try {
    const raw = window.localStorage.getItem(DEMO_STORAGE_KEY);
    if (!raw) return null;
    return normalizeUser(JSON.parse(raw) as DemoUser);
  } catch {
    return null;
  }
}

function ensureLoaded() {
  if (loaded) return;
  cachedUser = readFromStorage();
  loaded = true;
}

function commitUser(next: DemoUser) {
  saveDemoUser(next);
  savePublicProfile(next);
  cachedUser = next;
  loaded = true;
  emit();
}

function subscribeSession(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  ensureLoaded();
  listeners.add(listener);
  const handleStorage = (event: StorageEvent) => {
    if (event.key !== DEMO_STORAGE_KEY && event.key !== null) return;
    cachedUser = readFromStorage();
    emit();
  };
  window.addEventListener("storage", handleStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", handleStorage);
  };
}

function getSessionSnapshot(): DemoUser | null {
  if (typeof window === "undefined") return null;
  ensureLoaded();
  return cachedUser;
}

function getServerSnapshot(): DemoUser | null {
  return null;
}

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const user = useSyncExternalStore(
    subscribeSession,
    getSessionSnapshot,
    getServerSnapshot
  );

  const register = useCallback((input: RegisterInput) => {
    commitUser(createDemoUser(input));
  }, []);

  const login = useCallback((email: string, businessName: string) => {
    const existing = getSessionSnapshot();
    if (
      existing &&
      existing.profile.email.trim().toLowerCase() === email.trim().toLowerCase()
    ) {
      commitUser(normalizeUser(existing));
      return;
    }
    commitUser(
      createDemoUser({
        name: "",
        businessName: businessName.trim() || "Демо-бизнес",
        email: email.trim(),
        sphere: "Маркетинг",
        city: "Москва",
        reach: "1 000 подписчиков",
        offering: "Обмен рекламой и коллаборации",
      })
    );
  }, []);

  const logout = useCallback(() => {
    clearDemoUser();
    cachedUser = null;
    loaded = true;
    emit();
  }, []);

  const publishOffer = useCallback((input: PublishOfferInput): ActionResult => {
    const current = getSessionSnapshot();
    if (!current) return { ok: false, reason: "Войдите в аккаунт" };
    const normalized = normalizeUser(current);
    if (normalized.publishedThisWeek >= normalized.quotaLimit) {
      return {
        ok: false,
        reason:
          "Квота предложений на этой неделе исчерпана. Расширьте квоту за долки.",
      };
    }
    const offer = buildDemoOffer(normalized, input);
    commitUser({
      ...normalized,
      offers: [offer, ...normalized.offers],
      publishedThisWeek: normalized.publishedThisWeek + 1,
    });
    return { ok: true };
  }, []);

  const expandQuota = useCallback((): ActionResult => {
    const current = getSessionSnapshot();
    if (!current) return { ok: false, reason: "Войдите в аккаунт" };
    if (current.quotaExpanded) {
      return { ok: false, reason: "Квота уже расширена" };
    }
    if (current.balance < QUOTA_EXPAND_COST) {
      return { ok: false, reason: "Недостаточно долек на балансе" };
    }
    commitUser({
      ...current,
      quotaExpanded: true,
      quotaLimit: QUOTA_EXPANDED,
      balance: current.balance - QUOTA_EXPAND_COST,
    });
    return { ok: true };
  }, []);

  const removeOffer = useCallback((id: string) => {
    const current = getSessionSnapshot();
    if (!current) return;
    commitUser({
      ...current,
      offers: current.offers.filter((offer) => offer.id !== id),
    });
  }, []);

  const proposeDeal = useCallback((input: ProposeDealInput): ActionResult => {
    const current = getSessionSnapshot();
    if (!current) return { ok: false, reason: "Войдите в аккаунт" };
    if (
      current.deals.some(
        (deal) => deal.partner === input.partner && deal.status !== "completed"
      )
    ) {
      return {
        ok: false,
        reason: "У вас уже есть активная сделка с этим партнёром",
      };
    }
    commitUser({
      ...current,
      deals: [buildProposedDeal(input), ...current.deals],
    });
    return { ok: true };
  }, []);

  const confirmDeal = useCallback((id: string): ActionResult => {
    const current = getSessionSnapshot();
    if (!current) return { ok: false, reason: "Войдите в аккаунт" };
    const next = confirmDealSide(current, id, "me");
    if (!next) {
      return { ok: false, reason: "Сделка уже закрыта или подтверждена" };
    }
    const deal = next.deals.find((item) => item.id === id);
    commitUser(next);
    return { ok: true, completed: deal?.status === "completed" };
  }, []);

  const confirmDealAsPartner = useCallback((id: string): ActionResult => {
    const current = getSessionSnapshot();
    if (!current) return { ok: false, reason: "Войдите в аккаунт" };
    const next = confirmDealSide(current, id, "partner");
    if (!next) {
      return { ok: false, reason: "Сделка уже закрыта или подтверждена" };
    }
    const deal = next.deals.find((item) => item.id === id);
    commitUser(next);
    return { ok: true, completed: deal?.status === "completed" };
  }, []);

  const updatePassport = useCallback((input: PassportInput): ActionResult => {
    const current = getSessionSnapshot();
    if (!current) return { ok: false, reason: "Войдите в аккаунт" };
    commitUser({
      ...current,
      profile: {
        ...current.profile,
        lookingFor: input.lookingFor.trim(),
        contacts: input.contacts.trim(),
      },
    });
    return { ok: true };
  }, []);

  const value = useMemo<SessionContextValue>(
    () => ({
      user,
      isRegistered: user !== null,
      register,
      login,
      logout,
      publishOffer,
      expandQuota,
      removeOffer,
      proposeDeal,
      confirmDeal,
      confirmDealAsPartner,
      updatePassport,
    }),
    [
      user,
      register,
      login,
      logout,
      publishOffer,
      expandQuota,
      removeOffer,
      proposeDeal,
      confirmDeal,
      confirmDealAsPartner,
      updatePassport,
    ]
  );

  return (
    <SessionContext.Provider value={value}>{children}</SessionContext.Provider>
  );
}

export function useSession(): SessionContextValue {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error("useSession must be used within a SessionProvider");
  }
  return context;
}
