"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface RevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}

export function Reveal({ children, className, delay = 0 }: RevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    let observer: IntersectionObserver | null = null;
    const frame = window.requestAnimationFrame(() => {
      if (typeof IntersectionObserver === "undefined") {
        setAnimate(true);
        return;
      }

      const rect = node.getBoundingClientRect();
      const isInViewport = rect.top < window.innerHeight && rect.bottom > 0;
      if (isInViewport) return;

      observer = new IntersectionObserver(
        (entries) => {
          for (const entry of entries) {
            if (entry.isIntersecting) {
              setAnimate(true);
              observer?.disconnect();
            }
          }
        },
        { threshold: 0.15, rootMargin: "0px 0px -48px 0px" }
      );
      observer.observe(node);
    });

    return () => {
      window.cancelAnimationFrame(frame);
      observer?.disconnect();
    };
  }, []);

  return (
    <div
      ref={ref}
      className={cn(
        animate && "animate-in fade-in slide-in-from-bottom-4 ease-out",
        className
      )}
      style={{
        animationDuration: "600ms",
        animationDelay: `${delay}ms`,
        animationFillMode: "backwards",
      }}
    >
      {children}
    </div>
  );
}
