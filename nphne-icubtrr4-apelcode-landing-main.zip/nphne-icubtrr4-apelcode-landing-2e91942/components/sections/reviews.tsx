import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Reveal } from "@/components/reveal";

const reviews = [
  {
    name: "Марина К.",
    business: "Студия ногтевого сервиса",
    text: "Обменялись постами с кофейней рядом. Обе получили новых клиентов. Всё честно, сделка подтверждена на сайте.",
  },
  {
    name: "Дмитрий В.",
    business: "Фотостудия",
    text: "Провели совместный розыгрыш с мастерской свечей. Прибавилось подписчиков у обоих, приз нашёл победителя. Условия зафиксировали заранее — никто никого не подвёл.",
  },
  {
    name: "Екатерина Л.",
    business: "Кофейня",
    text: "Сделали кросс-промо в сторис со студией маникюра. Про нас узнала новая аудитория. Договориться было просто: всё записали в сделке и подтвердили выполнение.",
  },
];

function Stars() {
  return (
    <div
      className="flex items-center gap-1"
      role="img"
      aria-label="Оценка: 5 из 5"
    >
      {Array.from({ length: 5 }).map((_, index) => (
        <Star
          key={index}
          className="h-4 w-4 fill-primary text-primary"
          aria-hidden
        />
      ))}
    </div>
  );
}

export function Reviews() {
  return (
    <section id="reviews" aria-label="Отзывы" className="scroll-mt-20">
      <div className="container mx-auto px-4 py-24">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-medium text-primary uppercase tracking-wide">
              Отзывы
            </p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight text-balance sm:text-4xl">
              Бизнесы, которые уже обменялись
            </h2>
            <p className="mt-4 text-muted-foreground">
              Реальные бартеры, доведённые до результата.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {reviews.map((review, index) => (
            <Reveal key={review.name} delay={index * 120}>
              <Card className="card-hover h-full py-6">
                <CardContent className="flex h-full flex-col gap-5">
                  <Stars />
                  <blockquote className="text-sm leading-relaxed text-foreground/90">
                    «{review.text}»
                  </blockquote>
                  <footer className="mt-auto border-t border-border pt-4">
                    <p className="text-sm font-semibold">{review.name}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {review.business}
                    </p>
                  </footer>
                </CardContent>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
