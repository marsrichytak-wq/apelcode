"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  Handshake,
  LogIn,
  MapPin,
  SearchX,
  UserPlus,
  Users,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { buttonVariants } from "@/components/ui/button-variants";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Reveal } from "@/components/reveal";
import { cn } from "@/lib/utils";
import { offerCities, offerSpheres, offers, type Offer } from "@/lib/data";
import { useSession } from "@/components/session-provider";
import { ProposeDealDialog } from "@/components/forms/propose-deal-form";
import type { DemoDeal } from "@/lib/demo";

type CatalogOffer = Offer & { isOwn?: boolean };

const PREVIEW_COUNT = 6;
const ALL = "all";

export function Catalog() {
  const { user, isRegistered } = useSession();
  const [city, setCity] = useState<string>(ALL);
  const [sphere, setSphere] = useState<string>(ALL);
  const [type, setType] = useState<string>(ALL);
  const [visibleCount, setVisibleCount] = useState(PREVIEW_COUNT);
  const [loginOpen, setLoginOpen] = useState(false);
  const [detailOffer, setDetailOffer] = useState<CatalogOffer | null>(null);
  const [proposeOffer, setProposeOffer] = useState<CatalogOffer | null>(null);

  const dealByPartner = useMemo(() => {
    const map = new Map<string, DemoDeal>();
    if (user) {
      for (const deal of user.deals) {
        if (!map.has(deal.partner)) map.set(deal.partner, deal);
      }
    }
    return map;
  }, [user]);

  const allOffers = useMemo<CatalogOffer[]>(() => {
    if (!user) return offers;
    const ownOffers: CatalogOffer[] = user.offers.map((offer) => ({
      id: offer.id,
      businessName: user.profile.businessName,
      city: user.profile.city,
      sphere: user.profile.sphere,
      type: offer.type,
      description: offer.description,
      reach: user.profile.reach,
      engagement: offer.engagement,
      isOwn: true,
    }));
    return [...ownOffers, ...offers];
  }, [user]);

  const filtered = useMemo(
    () =>
      allOffers.filter(
        (offer) =>
          (city === ALL || offer.city === city) &&
          (sphere === ALL || offer.sphere === sphere) &&
          (type === ALL || offer.type === type)
      ),
    [allOffers, city, sphere, type]
  );

  const visibleOffers = filtered.slice(0, visibleCount);
  const hasMore = filtered.length > visibleCount;

  const handleCityChange = (value: string | null) => {
    setCity(value ?? ALL);
    setVisibleCount(PREVIEW_COUNT);
  };

  const handleSphereChange = (value: string | null) => {
    setSphere(value ?? ALL);
    setVisibleCount(PREVIEW_COUNT);
  };

  const handleTypeChange = (value: string | null) => {
    setType(value ?? ALL);
    setVisibleCount(PREVIEW_COUNT);
  };

  const handleDetails = (offer: CatalogOffer) => {
    if (isRegistered) {
      setDetailOffer(offer);
    } else {
      setLoginOpen(true);
    }
  };

  const handlePropose = (offer: CatalogOffer) => {
    if (!isRegistered) {
      setLoginOpen(true);
      return;
    }
    setProposeOffer(offer);
  };

  return (
    <section
      id="catalog"
      aria-label="Каталог предложений"
      className="scroll-mt-20"
    >
      <div className="container mx-auto px-4 py-24">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-medium text-primary uppercase tracking-wide">
              Каталог
            </p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight text-balance sm:text-4xl">
              Найдите партнёра для бартера
            </h2>
            <p className="mt-4 text-muted-foreground">
              Фильтруйте по городу, сфере и формату сотрудничества и выбирайте
              бизнес, который подходит именно вам.
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="mt-10 flex flex-wrap items-end justify-center gap-4">
            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-muted-foreground">
                Город
              </span>
              <Select value={city} onValueChange={handleCityChange}>
                <SelectTrigger
                  aria-label="Фильтр по городу"
                  className="min-w-44"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL}>Все города</SelectItem>
                  {offerCities.map((item) => (
                    <SelectItem key={item} value={item}>
                      {item}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-muted-foreground">
                Сфера
              </span>
              <Select value={sphere} onValueChange={handleSphereChange}>
                <SelectTrigger
                  aria-label="Фильтр по сфере"
                  className="min-w-44"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL}>Все сферы</SelectItem>
                  {offerSpheres.map((item) => (
                    <SelectItem key={item} value={item}>
                      {item}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <span className="text-xs font-medium text-muted-foreground">
                Тип
              </span>
              <Select value={type} onValueChange={handleTypeChange}>
                <SelectTrigger aria-label="Фильтр по типу" className="min-w-44">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL}>Все типы</SelectItem>
                  <SelectItem value="Бартер">Бартер</SelectItem>
                  <SelectItem value="Коллаборация">Коллаборация</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Reveal>

        {visibleOffers.length > 0 ? (
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {visibleOffers.map((offer, index) => (
              <Reveal key={offer.id} delay={index * 60}>
                <OfferCard
                  offer={offer}
                  dealWith={dealByPartner.get(offer.businessName)}
                  onDetails={() => handleDetails(offer)}
                  onPropose={() => handlePropose(offer)}
                />
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="mt-12 flex flex-col items-center gap-4 rounded-xl border border-border bg-card/50 px-4 py-16 text-center">
            <span className="flex size-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <SearchX className="size-6" aria-hidden />
            </span>
            <p className="text-sm text-muted-foreground">
              По заданным фильтрам ничего не найдено
            </p>
          </div>
        )}

        {hasMore && (
          <div className="mt-10 text-center">
            <Button
              variant="outline"
              size="lg"
              onClick={() => setVisibleCount(filtered.length)}
            >
              Смотреть все
              <ArrowRight data-icon="inline-end" aria-hidden />
            </Button>
          </div>
        )}
      </div>

      <Dialog open={loginOpen} onOpenChange={setLoginOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Войдите</DialogTitle>
            <DialogDescription>
              Чтобы увидеть подробности предложения и связаться с партнёром,
              войдите в аккаунт или зарегистрируйтесь.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:flex-col">
            <Link
              href="/login"
              className={cn(buttonVariants(), "w-full")}
              onClick={() => setLoginOpen(false)}
            >
              <LogIn data-icon="inline-start" aria-hidden />
              Войти
            </Link>
            <Link
              href="/register"
              className={cn(buttonVariants({ variant: "outline" }), "w-full")}
              onClick={() => setLoginOpen(false)}
            >
              <UserPlus data-icon="inline-start" aria-hidden />
              Зарегистрироваться
            </Link>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={Boolean(detailOffer)}
        onOpenChange={(open) => {
          if (!open) setDetailOffer(null);
        }}
      >
        <DialogContent className="sm:max-w-md">
          {detailOffer && (
            <>
              <DialogHeader>
                <DialogTitle>{detailOffer.businessName}</DialogTitle>
                <DialogDescription>
                  <span className="flex flex-wrap items-center gap-2">
                    <Badge
                      variant={
                        detailOffer.type === "Бартер" ? "default" : "secondary"
                      }
                    >
                      {detailOffer.type}
                    </Badge>
                    <span className="flex items-center gap-1">
                      <MapPin className="size-3.5 text-primary" aria-hidden />
                      {detailOffer.city}
                    </span>
                    <span>{detailOffer.sphere}</span>
                  </span>
                </DialogDescription>
              </DialogHeader>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {detailOffer.description}
              </p>
              {(() => {
                const deal = dealByPartner.get(detailOffer.businessName);
                if (!deal) return null;
                if (deal.status === "completed") {
                  return (
                    <p className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-xs text-primary">
                      <CheckCircle2 className="size-3.5 shrink-0" aria-hidden />
                      Сделка с этим партнёром закрыта — обе стороны подтвердили
                      выполнение.
                    </p>
                  );
                }
                return (
                  <div className="space-y-1 rounded-lg border border-border bg-background/60 p-3 text-xs">
                    <p className="font-semibold">
                      Активная сделка: {deal.title}
                    </p>
                    <p className="text-muted-foreground">
                      Вы подтвердили:{" "}
                      <span className="font-medium text-foreground">
                        {deal.myConfirmed ? "да" : "нет"}
                      </span>{" "}
                      · Партнёр подтвердил:{" "}
                      <span className="font-medium text-foreground">
                        {deal.partnerConfirmed ? "да" : "нет"}
                      </span>
                    </p>
                  </div>
                );
              })()}
              <dl className="grid grid-cols-2 gap-3 rounded-lg border border-border bg-background/60 p-4">
                <div>
                  <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Users className="size-3.5 text-primary" aria-hidden />
                    Охват
                  </dt>
                  <dd className="mt-1 text-sm font-semibold">
                    {detailOffer.reach}
                  </dd>
                </div>
                <div>
                  <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Activity className="size-3.5 text-primary" aria-hidden />
                    Вовлечённость
                  </dt>
                  <dd className="mt-1 text-sm font-semibold">
                    {detailOffer.engagement}
                  </dd>
                </div>
              </dl>
              {detailOffer.isOwn && (
                <p className="rounded-lg bg-primary/10 px-3 py-2 text-xs text-primary">
                  Это ваше предложение — оно уже опубликовано в каталоге.
                </p>
              )}
              <DialogFooter showCloseButton />
            </>
          )}
        </DialogContent>
      </Dialog>

      {proposeOffer && (
        <ProposeDealDialog
          key={proposeOffer.id}
          offer={proposeOffer}
          open={Boolean(proposeOffer)}
          onOpenChange={(open) => {
            if (!open) setProposeOffer(null);
          }}
        />
      )}
    </section>
  );
}

interface OfferCardProps {
  offer: CatalogOffer;
  dealWith?: DemoDeal;
  onDetails: () => void;
  onPropose: () => void;
}

function OfferCard({ offer, dealWith, onDetails, onPropose }: OfferCardProps) {
  const dealActive = dealWith?.status === "active";
  return (
    <Card className="card-hover h-full py-6">
      <CardContent className="flex h-full flex-col gap-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant={offer.type === "Бартер" ? "default" : "secondary"}>
              {offer.type}
            </Badge>
            {offer.isOwn && <Badge variant="outline">Ваше предложение</Badge>}
            {dealActive && <Badge variant="secondary">Активная сделка</Badge>}
            {dealWith?.status === "completed" && (
              <Badge variant="outline">Сделка закрыта</Badge>
            )}
          </div>
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <MapPin className="size-3.5 text-primary" aria-hidden />
            {offer.city}
          </span>
        </div>
        <div>
          <h3 className="text-lg font-semibold tracking-tight">
            {offer.businessName}
          </h3>
          <p className="mt-1 text-sm text-muted-foreground">{offer.sphere}</p>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">
          {offer.description}
        </p>
        <dl className="mt-auto grid grid-cols-2 gap-3 border-t border-border pt-4">
          <div>
            <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Users className="size-3.5 text-primary" aria-hidden />
              Охват
            </dt>
            <dd className="mt-1 text-sm font-semibold">{offer.reach}</dd>
          </div>
          <div>
            <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Activity className="size-3.5 text-primary" aria-hidden />
              Вовлечённость
            </dt>
            <dd className="mt-1 text-sm font-semibold">{offer.engagement}</dd>
          </div>
        </dl>
        <div className="flex flex-col gap-2">
          {!offer.isOwn && (
            <Button
              type="button"
              className="w-full"
              disabled={dealActive}
              onClick={onPropose}
            >
              <Handshake data-icon="inline-start" aria-hidden />
              {dealActive ? "Сделка уже активна" : "Предложить сделку"}
            </Button>
          )}
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={onDetails}
          >
            Подробнее
            <ArrowRight data-icon="inline-end" aria-hidden />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
