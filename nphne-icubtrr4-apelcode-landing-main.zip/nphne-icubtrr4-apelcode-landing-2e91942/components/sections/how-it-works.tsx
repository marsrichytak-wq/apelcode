import { BadgeCheck, FileSignature, Search, UserRound } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Reveal } from "@/components/reveal";

const steps = [
  {
    icon: UserRound,
    title: "Заполни профиль",
    description: "Укажи сферу, город, охваты и что можешь предложить.",
  },
  {
    icon: Search,
    title: "Найди партнёра",
    description: "Выбери из каталога или получи персональную подборку.",
  },
  {
    icon: FileSignature,
    title: "Зафиксируй сделку",
    description: "Опиши, кто что делает и к какому сроку.",
  },
  {
    icon: BadgeCheck,
    title: "Подтверди выполнение",
    description: "Обе стороны ставят галочку — сделка закрыта.",
  },
];

export function HowItWorks() {
  return (
    <section
      id="how-it-works"
      aria-label="Как это работает"
      className="scroll-mt-20"
    >
      <div className="container mx-auto px-4 py-24">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-medium text-primary uppercase tracking-wide">
              Как это работает
            </p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight text-balance sm:text-4xl">
              Четыре шага до результата
            </h2>
            <p className="mt-4 text-muted-foreground">
              Никакой суеты и устных договорённостей. Каждый бартер доводим до
              конца.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <Reveal key={step.title} delay={index * 120}>
              <Card className="card-hover h-full py-6">
                <CardContent className="flex h-full flex-col items-start gap-4">
                  <div className="flex w-full items-start justify-between">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
                      <step.icon className="h-6 w-6" aria-hidden />
                    </span>
                    <span className="text-sm font-semibold text-muted-foreground/50">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-base font-semibold">{step.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {step.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
