"use client";

import { useState } from "react";
import {
  BadgeCheck,
  CalendarClock,
  Handshake,
  Image,
  ListChecks,
  PartyPopper,
  ShoppingBag,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DealTemplate {
  id: string;
  title: string;
  description: string;
  icon: typeof Handshake;
  actions: string[];
  deadline: string;
  completion: string;
}

const templates: DealTemplate[] = [
  {
    id: "instagram-posts",
    title: "Обмен постами в Instagram",
    description: "Публикации о бизнесе партнёра в ленте",
    icon: Image,
    actions: [
      "Вы публикуете пост о бизнесе партнёра в своём Instagram.",
      "Партнёр публикует пост о вас в своём аккаунте.",
      "В постах — фото, ссылка на партнёра и короткая история сотрудничества.",
    ],
    deadline: "Оба поста выходят в течение 7 дней после подписания сделки.",
    completion:
      "Посты опубликованы, отмечены обеими сторонами и провисели в ленте минимум 48 часов.",
  },
  {
    id: "giveaway",
    title: "Совместный розыгрыш",
    description: "Приз и анонс — у вас, сбор участников — у партнёра",
    icon: PartyPopper,
    actions: [
      "Вы готовите приз и пост-анонс розыгрыша.",
      "Партнёр публикует розыгрыш в своём аккаунте и собирает участников.",
      "Условия участия и способ выбора победителя согласованы заранее.",
    ],
    deadline:
      "Анонс — в течение 3 дней после подписания сделки. Итоги подводятся через 14 дней после старта.",
    completion:
      "Розыгрыш проведён, победитель объявлен и получил приз, результаты зафиксированы в сделке.",
  },
  {
    id: "stories-cross-promo",
    title: "Кросс-промо в сторис",
    description: "Взаимные упоминания с активной ссылкой",
    icon: Sparkles,
    actions: [
      "Вы публикуете две сторис о партнёре с активной ссылкой на него.",
      "Партнёр делает то же самое в своём аккаунте.",
      "Даты выхода сторис согласуются заранее.",
    ],
    deadline:
      "Сторис выходят в течение 5 дней после подписания сделки в согласованные даты.",
    completion:
      "Сторис опубликованы, находились в эфире 24 часа и подтверждены обеими сторонами.",
  },
  {
    id: "product-bundle",
    title: "Совместный набор товаров",
    description: "Комбинированное предложение на двух площадках",
    icon: ShoppingBag,
    actions: [
      "Вы добавляете товар партнёра в совместный набор на своей площадке.",
      "Партнёр делает то же самое у себя и продвигает набор своей аудитории.",
      "Состав набора, цена и условия продажи согласованы заранее.",
    ],
    deadline:
      "Набор собран и опубликован в течение 10 дней после подписания сделки.",
    completion:
      "Совместный набор опубликован у обеих сторон, ссылки рабочие, выполнение подтверждено двумя подтверждениями.",
  },
];

export function DealTemplates() {
  const [selectedId, setSelectedId] = useState(templates[0].id);
  const selected =
    templates.find((template) => template.id === selectedId) ?? templates[0];

  return (
    <section
      id="templates"
      aria-label="Шаблоны сделок"
      className="scroll-mt-20"
    >
      <div className="container mx-auto px-4 py-24">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium text-primary uppercase tracking-wide">
            Шаблоны сделок
          </p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-balance sm:text-4xl">
            Не знаешь, с чего начать? Выбери сценарий
          </h2>
          <p className="mt-4 text-muted-foreground">
            Готовые условия сделки заполнятся автоматически. Останется только
            пригласить партнёра.
          </p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-[1fr_1.1fr]">
          <div className="grid gap-3 sm:grid-cols-2">
            {templates.map((template) => {
              const isActive = template.id === selectedId;
              return (
                <button
                  key={template.id}
                  type="button"
                  aria-pressed={isActive}
                  onClick={() => setSelectedId(template.id)}
                  className={cn(
                    "flex flex-col items-start gap-3 rounded-xl border p-4 text-left transition-all duration-200",
                    isActive
                      ? "border-primary/60 bg-primary/10 ring-1 ring-primary/40"
                      : "border-border bg-card hover:border-border hover:bg-muted/60"
                  )}
                >
                  <span
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-lg",
                      isActive
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    )}
                  >
                    <template.icon className="h-5 w-5" aria-hidden />
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">
                      {template.title}
                    </span>
                    <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                      {template.description}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          <div
            key={selected.id}
            className="animate-in fade-in slide-in-from-bottom-2 ease-out rounded-xl border border-border bg-card p-6 sm:p-8"
            style={{ animationDuration: "350ms" }}
          >
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <selected.icon className="h-5 w-5" aria-hidden />
              </span>
              <h3 className="text-lg font-semibold">{selected.title}</h3>
            </div>

            <dl className="mt-8 space-y-6">
              <div>
                <dt className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <ListChecks className="h-4 w-4 text-primary" aria-hidden />
                  Кто что делает
                </dt>
                <dd className="mt-2 space-y-1.5 pl-6">
                  <ul className="list-disc space-y-1.5 pl-4 text-sm leading-relaxed text-muted-foreground marker:text-primary">
                    {selected.actions.map((action) => (
                      <li key={action}>{action}</li>
                    ))}
                  </ul>
                </dd>
              </div>
              <div>
                <dt className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <CalendarClock className="h-4 w-4 text-primary" aria-hidden />
                  Сроки
                </dt>
                <dd className="mt-2 pl-6 text-sm leading-relaxed text-muted-foreground">
                  {selected.deadline}
                </dd>
              </div>
              <div>
                <dt className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <BadgeCheck className="h-4 w-4 text-primary" aria-hidden />
                  Что считается выполнением
                </dt>
                <dd className="mt-2 pl-6 text-sm leading-relaxed text-muted-foreground">
                  {selected.completion}
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}
