import Link from "next/link";
import { buttonVariants } from "@/components/ui/button-variants";
import { Reveal } from "@/components/reveal";
import { cn } from "@/lib/utils";

export function Cta() {
  return (
    <section
      id="cta"
      aria-label="Начать на платформе"
      className="relative overflow-hidden scroll-mt-20"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_100%,rgba(255,138,0,0.16),transparent)]"
      />
      <div className="container relative mx-auto px-4 py-28 text-center">
        <Reveal>
          <div className="mx-auto max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight text-balance sm:text-5xl">
              Готов найти партнёра?
            </h2>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link
                href="/register"
                className={cn(
                  buttonVariants({ size: "lg" }),
                  "w-full sm:w-auto"
                )}
              >
                Зарегистрироваться
              </Link>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">
              Бесплатно. Без комиссий.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
