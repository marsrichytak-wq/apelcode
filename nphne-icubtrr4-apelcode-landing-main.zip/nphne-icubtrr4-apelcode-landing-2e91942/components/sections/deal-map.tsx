"use client";

import type { LucideIcon } from "lucide-react";
import {
  BadgeCheck,
  Camera,
  Coffee,
  Croissant,
  Flame,
  Handshake,
  Megaphone,
  Palette,
  Shirt,
} from "lucide-react";
import { Reveal } from "@/components/reveal";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const VIEWBOX_WIDTH = 760;
const VIEWBOX_HEIGHT = 430;

interface BusinessNode {
  id: string;
  label: string;
  x: number;
  y: number;
  icon: LucideIcon;
}

interface DealEdge {
  id: string;
  from: string;
  to: string;
  type: string;
  date: string;
}

const nodes: BusinessNode[] = [
  { id: "coffee", label: "Кофейня А", x: 110, y: 105, icon: Coffee },
  { id: "studio", label: "Студия Б", x: 375, y: 60, icon: Palette },
  { id: "photo", label: "Фотостудия", x: 645, y: 100, icon: Camera },
  { id: "bakery", label: "Пекарня", x: 125, y: 330, icon: Croissant },
  { id: "candles", label: "Мастерская свечей", x: 400, y: 300, icon: Flame },
  { id: "smm", label: "SMM-агентство", x: 655, y: 330, icon: Megaphone },
  { id: "showroom", label: "Шоурум", x: 260, y: 180, icon: Shirt },
];

const deals: DealEdge[] = [
  {
    id: "deal-1",
    from: "coffee",
    to: "studio",
    type: "Обмен постами",
    date: "15.10.2026",
  },
  {
    id: "deal-2",
    from: "studio",
    to: "photo",
    type: "Совместный розыгрыш",
    date: "02.09.2026",
  },
  {
    id: "deal-3",
    from: "coffee",
    to: "showroom",
    type: "Кросс-промо в сторис",
    date: "28.08.2026",
  },
  {
    id: "deal-4",
    from: "showroom",
    to: "studio",
    type: "Обмен постами",
    date: "12.07.2026",
  },
  {
    id: "deal-5",
    from: "bakery",
    to: "candles",
    type: "Совместный набор товаров",
    date: "05.09.2026",
  },
  {
    id: "deal-6",
    from: "candles",
    to: "smm",
    type: "Кросс-промо в сторис",
    date: "19.08.2026",
  },
  {
    id: "deal-7",
    from: "showroom",
    to: "candles",
    type: "Обмен рекламой",
    date: "01.06.2026",
  },
  {
    id: "deal-8",
    from: "candles",
    to: "studio",
    type: "Совместный розыгрыш",
    date: "22.05.2026",
  },
];

const nodeById = new Map(nodes.map((node) => [node.id, node]));

function getNode(id: string): BusinessNode {
  const node = nodeById.get(id);
  if (!node) throw new Error(`Unknown node: ${id}`);
  return node;
}

export function DealMap() {
  return (
    <section id="map" aria-label="Карта сделок" className="scroll-mt-20">
      <div className="container mx-auto px-4 py-24">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-medium text-primary uppercase tracking-wide">
              Карта сделок
            </p>
            <h2 className="mt-3 text-3xl font-bold tracking-tight text-balance sm:text-4xl">
              Бартерный след
            </h2>
            <p className="mt-4 text-muted-foreground">
              Как бизнесы связаны друг с другом подтверждёнными сделками.
            </p>
          </div>
        </Reveal>

        <Reveal delay={120} className="mt-14">
          <div className="rounded-2xl border border-border bg-card/40 bg-[radial-gradient(circle,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:22px_22px] p-4 sm:p-6">
            <TooltipProvider delay={150}>
              <svg
                viewBox={`0 0 ${VIEWBOX_WIDTH} ${VIEWBOX_HEIGHT}`}
                className="h-auto w-full"
                role="img"
                aria-label="Сетка сделок: кружки-бизнесы соединены линиями подтверждённых сделок"
              >
                {deals.map((deal) => {
                  const from = getNode(deal.from);
                  const to = getNode(deal.to);
                  return (
                    <Tooltip key={deal.id}>
                      <TooltipTrigger
                        render={
                          <g className="group cursor-pointer">
                            <line
                              x1={from.x}
                              y1={from.y}
                              x2={to.x}
                              y2={to.y}
                              stroke="transparent"
                              strokeWidth={20}
                              strokeLinecap="round"
                            />
                            <line
                              x1={from.x}
                              y1={from.y}
                              x2={to.x}
                              y2={to.y}
                              className="stroke-primary/45 transition-[stroke] duration-200 group-hover:stroke-primary"
                              strokeWidth={2.5}
                              strokeLinecap="round"
                            />
                          </g>
                        }
                      />
                      <TooltipContent
                        side="top"
                        align="center"
                        className="flex-col items-start gap-1.5"
                      >
                        <span className="flex items-center gap-1.5 font-semibold">
                          <Handshake
                            className="size-4 shrink-0 text-primary"
                            aria-hidden
                          />
                          {from.label} ↔ {to.label}
                        </span>
                        <span className="text-background/75">{deal.type}</span>
                        <span className="flex items-center gap-1 text-background/75">
                          <BadgeCheck
                            className="size-3.5 shrink-0"
                            aria-hidden
                          />
                          Подтверждено · {deal.date}
                        </span>
                      </TooltipContent>
                    </Tooltip>
                  );
                })}

                {nodes.map((node) => {
                  const Icon = node.icon;
                  return (
                    <g key={node.id}>
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r={26}
                        fill="var(--card)"
                        stroke="var(--ring)"
                        strokeWidth={1.5}
                      />
                      <Icon
                        x={node.x - 12}
                        y={node.y - 12}
                        width={24}
                        height={24}
                        className="text-primary"
                        aria-hidden
                      />
                      <text
                        x={node.x}
                        y={node.y + 48}
                        textAnchor="middle"
                        className="fill-foreground text-[13px] font-medium"
                      >
                        {node.label}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </TooltipProvider>
          </div>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Реальные сделки, подтверждённые обеими сторонами
          </p>
        </Reveal>
      </div>
    </section>
  );
}
