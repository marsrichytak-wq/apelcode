import Link from "next/link";
import { Image as ImageIcon } from "lucide-react";

const footerLinks = [
  { href: "#", label: "О проекте" },
  { href: "#", label: "Пользовательское соглашение" },
  { href: "#", label: "Контакты" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background/60">
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <Link href="/" className="flex items-center gap-3">
            <span
              aria-hidden
              className="flex h-10 w-10 items-center justify-center rounded-lg border border-dashed border-border bg-muted/50 text-muted-foreground"
            >
              <ImageIcon className="h-4 w-4" />
            </span>
            <span className="text-lg font-semibold tracking-tight">
              АпельКод
            </span>
          </Link>

          <nav aria-label="Ссылки в футере" className="flex flex-col gap-3">
            {footerLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="mt-10 border-t border-border pt-6">
          <p className="text-sm text-muted-foreground">© 2026 АпельКод</p>
        </div>
      </div>
    </footer>
  );
}
