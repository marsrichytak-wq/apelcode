export type OfferType = "Бартер" | "Коллаборация";

export interface Offer {
  id: string;
  businessName: string;
  city: string;
  sphere: string;
  type: OfferType;
  description: string;
  reach: string;
  engagement: string;
}

export const offers: Offer[] = [
  {
    id: "coffee-apelsin",
    businessName: "Кофейня «Апельсин»",
    city: "Москва",
    sphere: "Кофейни",
    type: "Бартер",
    description:
      "Обмен постами и сторис с аудиторией, которая ценит specialty-кофе.",
    reach: "18 400 подписчиков",
    engagement: "4.8%",
  },
  {
    id: "nails-lavanda",
    businessName: "Студия ногтей «Лаванда»",
    city: "Санкт-Петербург",
    sphere: "Красота",
    type: "Бартер",
    description: "Взаимные посты и сторис. Верим в честный обмен с соседями.",
    reach: "9 200 подписчиков",
    engagement: "6.1%",
  },
  {
    id: "photo-kadr",
    businessName: "Фотостудия «Кадр»",
    city: "Казань",
    sphere: "Фото и видео",
    type: "Коллаборация",
    description:
      "Совместные съёмки и розыгрыши с брендами из сферы красоты и еды.",
    reach: "24 800 подписчиков",
    engagement: "5.4%",
  },
  {
    id: "fitness-impuls",
    businessName: "Фитнес-клуб «Импульс»",
    city: "Новосибирск",
    sphere: "Фитнес",
    type: "Бартер",
    description: "Кросс-промо в сторис и совместные челленджи с кофейнями.",
    reach: "31 500 подписчиков",
    engagement: "7.2%",
  },
  {
    id: "smm-mediafokus",
    businessName: "SMM-агентство «МедиаФокус»",
    city: "Москва",
    sphere: "Маркетинг",
    type: "Коллаборация",
    description: "Поможем с контентом в обмен на продвижение вашего бизнеса.",
    reach: "15 300 подписчиков",
    engagement: "3.9%",
  },
  {
    id: "candles-teply-svet",
    businessName: "Мастерская свечей «Тёплый свет»",
    city: "Екатеринбург",
    sphere: "Хендмейд",
    type: "Бартер",
    description: "Обмен постами и подарки для розыгрышей ваших партнёров.",
    reach: "6 800 подписчиков",
    engagement: "8.3%",
  },
  {
    id: "kids-karapuz",
    businessName: "Детская студия «Карапуз»",
    city: "Казань",
    sphere: "Детские товары",
    type: "Коллаборация",
    description: "Совместный набор товаров и взаимные анонсы мероприятий.",
    reach: "12 900 подписчиков",
    engagement: "5.1%",
  },
  {
    id: "barbershop-britva",
    businessName: "Барбершоп «Бритва»",
    city: "Санкт-Петербург",
    sphere: "Красота",
    type: "Бартер",
    description: "Обмен постами в Instagram с кофейнями и фотостудиями.",
    reach: "14 700 подписчиков",
    engagement: "4.2%",
  },
  {
    id: "bakery-zerno",
    businessName: "Пекарня «Зерно»",
    city: "Москва",
    sphere: "Кофейни",
    type: "Бартер",
    description: "Кросс-промо со спортивными клубами и офисами рядом.",
    reach: "8 600 подписчиков",
    engagement: "6.7%",
  },
  {
    id: "english-speakup",
    businessName: "Онлайн-школа «SpeakUp»",
    city: "Новосибирск",
    sphere: "Образование",
    type: "Коллаборация",
    description: "Совместные вебинары и взаимная реклама в Telegram-каналах.",
    reach: "27 400 подписчиков",
    engagement: "4.6%",
  },
  {
    id: "stretching-gibkost",
    businessName: "Студия растяжки «Гибкость»",
    city: "Екатеринбург",
    sphere: "Фитнес",
    type: "Коллаборация",
    description: "Совместные мероприятия и обмен сторис с кафе и студиями.",
    reach: "10 100 подписчиков",
    engagement: "5.9%",
  },
  {
    id: "jewelry-kraska",
    businessName: "Ювелирная мастерская «Краска»",
    city: "Санкт-Петербург",
    sphere: "Хендмейд",
    type: "Бартер",
    description: "Обмен постами и участие в розыгрышах партнёров.",
    reach: "7 400 подписчиков",
    engagement: "9.1%",
  },
];

export const offerCities = Array.from(
  new Set(offers.map((offer) => offer.city))
).sort();

export const offerSpheres = Array.from(
  new Set(offers.map((offer) => offer.sphere))
).sort();
