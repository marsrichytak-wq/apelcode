import type { PublicProfile } from "@/lib/demo";

export function passportUrl(publicId: string): string {
  if (typeof window === "undefined") {
    return `/passport?u=${encodeURIComponent(publicId)}`;
  }
  return `${window.location.origin}/passport?u=${encodeURIComponent(publicId)}`;
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(area);
      return ok;
    } catch {
      return false;
    }
  }
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function cardLine(value: string, maxLength: number): string {
  const single = value.replace(/\s+/g, " ").trim();
  return single.length > maxLength
    ? `${single.slice(0, maxLength - 1)}…`
    : single;
}

export function buildBusinessCardSvg(profile: PublicProfile): string {
  const businessName = escapeXml(cardLine(profile.businessName, 32));
  const sphere = escapeXml(cardLine(profile.sphere, 20));
  const city = escapeXml(cardLine(profile.city, 20));
  const reach = escapeXml(cardLine(profile.reach, 24));
  const contacts = escapeXml(cardLine(profile.contacts || profile.email, 26));
  const initials = escapeXml(
    (profile.businessName.trim().charAt(0) || "А").toUpperCase()
  );

  const field = (label: string, value: string, x: number, y: number) =>
    [
      `<text x="${x}" y="${y}" font-family="system-ui, Arial, sans-serif" font-size="9" letter-spacing="2" fill="#a89c8d">${label}</text>`,
      `<text x="${x}" y="${y + 17}" font-family="system-ui, Arial, sans-serif" font-size="14" font-weight="600" fill="#f5f1ea">${value}</text>`,
    ].join("");

  const svg = [
    `<svg xmlns="http://www.w3.org/2000/svg" width="420" height="260" viewBox="0 0 420 260" font-family="system-ui, Arial, sans-serif">`,
    `<defs>`,
    `<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">`,
    `<stop offset="0" stop-color="#241d14"/>`,
    `<stop offset="1" stop-color="#16120d"/>`,
    `</linearGradient>`,
    `</defs>`,
    `<rect width="420" height="260" rx="18" fill="url(#bg)"/>`,
    `<rect x="0" y="0" width="8" height="260" fill="#ff8a00"/>`,
    `<circle cx="52" cy="48" r="22" fill="#ff8a00"/>`,
    `<text x="52" y="48" text-anchor="middle" dominant-baseline="central" font-size="20" font-weight="700" fill="#16120d">${initials}</text>`,
    `<text x="86" y="42" font-size="20" font-weight="700" fill="#f5f1ea">${businessName}</text>`,
    `<text x="86" y="62" font-size="11" fill="#a89c8d">${sphere} · ${city}</text>`,
    `<line x1="34" y1="92" x2="386" y2="92" stroke="#3a2f22" stroke-width="1"/>`,
    field("СФЕРА", sphere, 40, 128),
    field("ГОРОД", city, 232, 128),
    field("ОХВАТ", reach, 40, 180),
    field("КОНТАКТЫ", contacts, 232, 180),
    `<text x="210" y="234" text-anchor="middle" font-size="10" letter-spacing="3" fill="#ff8a00">АПЕЛЬКОД · БЕЗОПАСНЫЙ БАРТЕР</text>`,
    `</svg>`,
  ].join("");

  return svg;
}

export function downloadBusinessCardSvg(profile: PublicProfile): void {
  const svg = buildBusinessCardSvg(profile);
  const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `vizitka-${profile.publicId}.svg`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
