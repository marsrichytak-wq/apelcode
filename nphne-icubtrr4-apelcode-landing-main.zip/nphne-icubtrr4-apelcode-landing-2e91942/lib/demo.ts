import type { OfferType } from "@/lib/data";

export const DEMO_STORAGE_KEY = "apelkod.demo.user.v1";
export const PUBLIC_PROFILES_KEY = "apelkod.demo.public-profiles.v1";

export const QUOTA_BASE = 3;
export const QUOTA_EXPANDED = 5;
export const QUOTA_EXPAND_COST = 5;

export interface RegisterInput {
  name: string;
  businessName: string;
  email: string;
  sphere: string;
  city: string;
  reach: string;
  offering: string;
  lookingFor?: string;
  contacts?: string;
}

export interface DemoOffer {
  id: string;
  type: OfferType;
  description: string;
  engagement: string;
  createdAt: string;
}

export type DealStatus = "active" | "completed";

export interface DemoDeal {
  id: string;
  partner: string;
  title: string;
  youDo: string;
  partnerDoes: string;
  deadline: string;
  status: DealStatus;
  myConfirmed: boolean;
  partnerConfirmed: boolean;
  myConfirmedAt?: string;
  partnerConfirmedAt?: string;
}

export interface DemoUser {
  publicId: string;
  profile: RegisterInput;
  registeredAt: string;
  balance: number;
  trustCompleted: number;
  trustTotal: number;
  quotaLimit: number;
  quotaExpanded: boolean;
  publishedThisWeek: number;
  quotaWeekKey: string;
  offers: DemoOffer[];
  deals: DemoDeal[];
}

export interface PublicProfile {
  publicId: string;
  name: string;
  businessName: string;
  email: string;
  sphere: string;
  city: string;
  reach: string;
  offering: string;
  lookingFor: string;
  contacts: string;
  trustPercent: number;
  offers: Array<{
    type: OfferType;
    description: string;
    engagement: string;
  }>;
}

const MONTHS_GENITIVE = [
  "января",
  "февраля",
  "марта",
  "апреля",
  "мая",
  "июня",
  "июля",
  "августа",
  "сентября",
  "октября",
  "ноября",
  "декабря",
];

const MONTHS_NOMINATIVE = [
  "январь",
  "февраль",
  "март",
  "апрель",
  "май",
  "июнь",
  "июль",
  "август",
  "сентябрь",
  "октябрь",
  "ноябрь",
  "декабрь",
];

export function todayUtc(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDaysUtc(dateStr: string, days: number): string {
  const [year, month, day] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day + days))
    .toISOString()
    .slice(0, 10);
}

export function isOverdue(deadline: string): boolean {
  return deadline < todayUtc();
}

export function daysUntil(deadline: string): number {
  const [year, month, day] = deadline.split("-").map(Number);
  const [currentYear, currentMonth, currentDay] = todayUtc()
    .split("-")
    .map(Number);
  const target = Date.UTC(year, month - 1, day);
  const now = Date.UTC(currentYear, currentMonth - 1, currentDay);
  return Math.round((target - now) / 86_400_000);
}

export function formatDate(dateStr: string): string {
  const [year, month, day] = dateStr.split("-").map(Number);
  return `${day} ${MONTHS_GENITIVE[month - 1]} ${year}`;
}

export function formatMonth(dateStr: string): string {
  const [year, month] = dateStr.split("-").map(Number);
  return `${MONTHS_NOMINATIVE[month - 1]} ${year}`;
}

export function weekKey(dateStr: string): string {
  const [year, month, day] = dateStr.split("-").map(Number);
  return String(Math.floor(Date.UTC(year, month - 1, day) / 604_800_000));
}

export function trustPercent(user: DemoUser): number {
  if (user.trustTotal === 0) return 100;
  return Math.round((user.trustCompleted / user.trustTotal) * 100);
}

export function quotaRemaining(user: DemoUser): number {
  return Math.max(0, user.quotaLimit - user.publishedThisWeek);
}

function makeId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function publicIdFromEmail(email: string): string {
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    hash = (hash * 31 + email.charCodeAt(i)) >>> 0;
  }
  return `p${hash.toString(36)}`;
}

export const DEAL_REWARD_DOLKI = 5;

export function createDemoDeals(today: string): DemoDeal[] {
  return [
    {
      id: "deal-1",
      partner: "Кофейня «Апельсин»",
      title: "Обмен постами в Instagram",
      youDo: "Публикуете пост о кофейне в своём аккаунте",
      partnerDoes: "Кофейня публикует пост о вас в своём аккаунте",
      deadline: addDaysUtc(today, 4),
      status: "active",
      myConfirmed: false,
      partnerConfirmed: false,
    },
    {
      id: "deal-2",
      partner: "Фотостудия «Кадр»",
      title: "Совместный розыгрыш",
      youDo: "Готовите приз и пост-анонс розыгрыша",
      partnerDoes: "Студия публикует розыгрыш и собирает участников",
      deadline: addDaysUtc(today, 11),
      status: "active",
      myConfirmed: false,
      partnerConfirmed: true,
      partnerConfirmedAt: addDaysUtc(today, -1),
    },
    {
      id: "deal-3",
      partner: "Барбершоп «Бритва»",
      title: "Кросс-промо в сторис",
      youDo: "Публикуете две сторис о барбершопе",
      partnerDoes: "Барбершоп публикует две сторис о вас",
      deadline: addDaysUtc(today, -2),
      status: "active",
      myConfirmed: true,
      partnerConfirmed: false,
      myConfirmedAt: addDaysUtc(today, -3),
    },
  ];
}

export interface ProposeDealInput {
  partner: string;
  title: string;
  youDo: string;
  partnerDoes: string;
  deadline: string;
}

export function buildProposedDeal(input: ProposeDealInput): DemoDeal {
  return {
    id: makeId(),
    partner: input.partner,
    title: input.title,
    youDo: input.youDo,
    partnerDoes: input.partnerDoes,
    deadline: input.deadline,
    status: "active",
    myConfirmed: false,
    partnerConfirmed: false,
  };
}

export function normalizeDeals(deals: DemoDeal[]): DemoDeal[] {
  return deals.map((deal) => ({
    ...deal,
    partnerDoes: deal.partnerDoes ?? "",
    status: deal.status ?? "active",
    myConfirmed: deal.myConfirmed ?? false,
    partnerConfirmed: deal.partnerConfirmed ?? false,
  }));
}

export function findDealWith(
  user: DemoUser,
  partner: string
): DemoDeal | undefined {
  return user.deals.find((deal) => deal.partner === partner);
}

export function hasActiveDealWith(user: DemoUser, partner: string): boolean {
  return user.deals.some(
    (deal) => deal.partner === partner && deal.status !== "completed"
  );
}

export function confirmDealSide(
  user: DemoUser,
  dealId: string,
  side: "me" | "partner"
): DemoUser | null {
  const deal = user.deals.find((item) => item.id === dealId);
  if (!deal || deal.status === "completed") return null;
  const mine = side === "me";
  if (mine ? deal.myConfirmed : deal.partnerConfirmed) return null;

  const confirmedDeal: DemoDeal = {
    ...deal,
    myConfirmed: mine ? true : deal.myConfirmed,
    partnerConfirmed: mine ? deal.partnerConfirmed : true,
    myConfirmedAt: mine ? todayUtc() : deal.myConfirmedAt,
    partnerConfirmedAt: mine ? deal.partnerConfirmedAt : todayUtc(),
  };

  const bothConfirmed =
    confirmedDeal.myConfirmed && confirmedDeal.partnerConfirmed;
  const nextStatus: DealStatus = bothConfirmed ? "completed" : "active";
  const deals = user.deals.map((item) =>
    item.id === dealId ? { ...confirmedDeal, status: nextStatus } : item
  );

  if (!bothConfirmed) return { ...user, deals };
  return {
    ...user,
    deals,
    trustTotal: user.trustTotal + 1,
    trustCompleted: user.trustCompleted + 1,
    balance: user.balance + DEAL_REWARD_DOLKI,
  };
}

export function createDemoUser(input: RegisterInput): DemoUser {
  const today = todayUtc();
  return {
    publicId: makeId(),
    profile: {
      ...input,
      lookingFor: input.lookingFor ?? "",
      contacts: input.contacts ?? "",
    },
    registeredAt: new Date().toISOString(),
    balance: 7,
    trustCompleted: 12,
    trustTotal: 12,
    quotaLimit: QUOTA_BASE,
    quotaExpanded: false,
    publishedThisWeek: 0,
    quotaWeekKey: weekKey(today),
    offers: [],
    deals: createDemoDeals(today),
  };
}

export function normalizeUser(user: DemoUser): DemoUser {
  const today = todayUtc();
  const key = weekKey(today);
  const normalized: DemoUser = {
    ...user,
    publicId: user.publicId || publicIdFromEmail(user.profile.email),
    profile: {
      ...user.profile,
      lookingFor: user.profile.lookingFor ?? "",
      contacts: user.profile.contacts ?? "",
    },
    offers: user.offers ?? [],
    deals: normalizeDeals(user.deals ?? []),
  };
  if (normalized.quotaWeekKey === key) {
    return normalized;
  }
  return {
    ...normalized,
    quotaWeekKey: key,
    publishedThisWeek: 0,
  };
}

export function buildPublicProfile(user: DemoUser): PublicProfile {
  return {
    publicId: user.publicId,
    name: user.profile.name ?? "",
    businessName: user.profile.businessName ?? "",
    email: user.profile.email ?? "",
    sphere: user.profile.sphere ?? "",
    city: user.profile.city ?? "",
    reach: user.profile.reach ?? "",
    offering: user.profile.offering ?? "",
    lookingFor: user.profile.lookingFor ?? "",
    contacts: user.profile.contacts ?? "",
    trustPercent: trustPercent(user),
    offers: (user.offers ?? []).map((offer) => ({
      type: offer.type,
      description: offer.description,
      engagement: offer.engagement,
    })),
  };
}

export function savePublicProfile(user: DemoUser): void {
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(PUBLIC_PROFILES_KEY);
    const map: Record<string, PublicProfile> = raw
      ? (JSON.parse(raw) as Record<string, PublicProfile>)
      : {};
    map[user.publicId] = buildPublicProfile(user);
    window.localStorage.setItem(PUBLIC_PROFILES_KEY, JSON.stringify(map));
  } catch {
    return;
  }
}

export function loadPublicProfile(publicId: string): PublicProfile | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(PUBLIC_PROFILES_KEY);
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, PublicProfile>;
    return map[publicId] ?? null;
  } catch {
    return null;
  }
}

export function buildDemoOffer(
  user: DemoUser,
  input: { type: OfferType; description: string; engagement: string }
): DemoOffer {
  return {
    id: makeId(),
    type: input.type,
    description: input.description,
    engagement: input.engagement,
    createdAt: todayUtc(),
  };
}

export function loadDemoUser(): DemoUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(DEMO_STORAGE_KEY);
    if (!raw) return null;
    return normalizeUser(JSON.parse(raw) as DemoUser);
  } catch {
    return null;
  }
}

export function saveDemoUser(user: DemoUser): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(user));
}

export function clearDemoUser(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(DEMO_STORAGE_KEY);
}
