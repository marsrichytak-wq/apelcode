import type { Metadata } from "next";
import { ProfileCabinet } from "@/components/cabinet/profile-cabinet";

export const metadata: Metadata = {
  title: "Личный кабинет — АпельКод",
  description:
    "Рейтинг доверия, баланс долек, квота предложений и активные сделки.",
};

export default function ProfilePage() {
  return <ProfileCabinet />;
}
