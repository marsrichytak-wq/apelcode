import type { Metadata } from "next";
import { RegisterForm } from "@/components/forms/register-form";

export const metadata: Metadata = {
  title: "Регистрация — АпельКод",
  description:
    "Создайте профиль и начните обмениваться рекламой с другими бизнесами.",
};

export default function RegisterPage() {
  return (
    <section className="container mx-auto px-4 py-16 sm:py-24">
      <div className="mx-auto max-w-2xl">
        <div className="mx-auto max-w-xl text-center">
          <p className="text-sm font-medium text-primary uppercase tracking-wide">
            Регистрация
          </p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-balance sm:text-4xl">
            Создайте профиль бизнеса
          </h1>
          <p className="mt-4 text-muted-foreground">
            Укажите сферу, город, охваты и что предлагаете — ваша карточка
            появится в каталоге, а в личном кабинете будут квота, долки и
            сделки.
          </p>
        </div>

        <div className="mt-10 rounded-xl border border-border bg-card p-6 sm:p-8">
          <RegisterForm />
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Демо-режим: данные хранятся локально в вашем браузере и никуда не
          отправляются.
        </p>
      </div>
    </section>
  );
}
