import type { Metadata } from "next";
import "./globals.css";
import { Inter } from "next/font/google";
import { cn } from "@/lib/utils";
import { BridgeProvider } from "@/components/bridge-provider";
import { SessionProvider } from "@/components/session-provider";
import { Toaster } from "@/components/ui/sonner";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

const inter = Inter({
  subsets: ["cyrillic", "latin"],
  variable: "--font-sans",
});

const appName = "АпельКод";

export const metadata: Metadata = {
  title: `${appName} — безопасный бартер и коллаборации`,
  description:
    "Найди партнёра для бартера. Обменивайся рекламой с другими бизнесами. Фиксируй сделку. Подтверждай выполнение. Без денег, без риска.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" className={cn("font-sans", inter.variable)}>
      <body className="antialiased min-h-screen bg-background flex flex-col">
        <BridgeProvider />
        <SessionProvider>
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <SiteFooter />
        </SessionProvider>
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
