import type { Metadata } from "next";
import { LoginForm } from "@/components/forms/login-form";

export const metadata: Metadata = {
  title: "Вход — АпельКод",
  description: "Войдите в аккаунт АпельКод и продолжайте бартерные сделки.",
};

export default function LoginPage() {
  return (
    <section className="container mx-auto px-4 py-16 sm:py-24">
      <div className="mx-auto max-w-md">
        <div className="text-center">
          <p className="text-sm font-medium text-primary uppercase tracking-wide">
            Вход
          </p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-balance">
            С возвращением!
          </h1>
          <p className="mt-4 text-muted-foreground">
            Войдите, чтобы продолжить сделки и вести профиль.
          </p>
        </div>

        <div className="mt-10 rounded-xl border border-border bg-card p-6 sm:p-8">
          <LoginForm />
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Демо-режим: вход не использует пароль, данные хранятся в вашем
          браузере.
        </p>
      </div>
    </section>
  );
}
