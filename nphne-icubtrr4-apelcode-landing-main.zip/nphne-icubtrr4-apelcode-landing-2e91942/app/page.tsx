import Link from "next/link";
import { PiggyBank } from "lucide-react";
import { buttonVariants } from "@/components/ui/button-variants";
import { Catalog } from "@/components/sections/catalog";
import { DealMap } from "@/components/sections/deal-map";
import { DealTemplates } from "@/components/sections/deal-templates";
import { HowItWorks } from "@/components/sections/how-it-works";
import { Reviews } from "@/components/sections/reviews";
import { Cta } from "@/components/sections/cta";
import { cn } from "@/lib/utils";

export default function HomePage() {
  return (
    <>
      <section id="hero" className="relative overflow-hidden">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(255,138,0,0.18),transparent)]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:28px_28px] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)]"
        />

        <div className="container relative mx-auto px-4 pt-24 pb-28 text-center sm:pt-32 sm:pb-36">
          <h1 className="mx-auto max-w-3xl text-4xl font-bold tracking-tight text-balance sm:text-6xl">
            Найди партнёра для бартера.{" "}
            <span className="text-primary">Не будь кинутым.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            Обменивайся рекламой с другими бизнесами. Фиксируй сделку.
            Подтверждай выполнение. Без денег, без риска.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              href="#catalog"
              className={cn(buttonVariants({ size: "lg" }), "w-full sm:w-auto")}
            >
              Найти партнёра
            </Link>
            <Link
              href="#how-it-works"
              className={cn(
                buttonVariants({ variant: "outline", size: "lg" }),
                "w-full sm:w-auto"
              )}
            >
              Как это работает
            </Link>
          </div>
          <p className="mt-12 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-5 py-2.5 text-sm text-muted-foreground">
            <PiggyBank className="h-4 w-4 text-primary" />
            Уже сэкономлено на рекламе:{" "}
            <span className="font-semibold text-foreground">2 340 000 ₽</span>
          </p>
        </div>
      </section>

      <Catalog />
      <HowItWorks />
      <DealTemplates />
      <DealMap />
      <Reviews />
      <Cta />
    </>
  );
}
