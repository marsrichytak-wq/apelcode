import type { Metadata } from "next";
import { Suspense } from "react";
import { PassportView } from "@/components/passport/passport-view";

export const metadata: Metadata = {
  title: "Паспорт партнёра — АпельКод",
  description:
    "Публичная карточка бизнеса для бартера и коллабораций: кто вы, что предлагаете и с кем хотите объединиться.",
};

export default function PassportPage() {
  return (
    <section aria-label="Паспорт партнёра">
      <div className="container mx-auto px-4 py-12 sm:py-16">
        <Suspense
          fallback={
            <div className="mx-auto max-w-xl space-y-4 rounded-2xl border border-border bg-card p-8">
              <div className="h-16 w-16 animate-pulse rounded-2xl bg-muted" />
              <div className="h-6 w-48 animate-pulse rounded bg-muted" />
              <div className="h-4 w-64 animate-pulse rounded bg-muted" />
              <div className="h-32 animate-pulse rounded-lg bg-muted" />
            </div>
          }
        >
          <PassportView />
        </Suspense>
      </div>
    </section>
  );
}
