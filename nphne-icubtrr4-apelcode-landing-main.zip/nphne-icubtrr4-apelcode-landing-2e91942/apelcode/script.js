document.addEventListener('DOMContentLoaded', () => {
  const cityFilter = document.getElementById('filter-city');
  const sphereFilter = document.getElementById('filter-sphere');
  const typeFilter = document.getElementById('filter-type');
  const resetBtn = document.getElementById('filter-reset');
  const cards = document.querySelectorAll('#cards-container .card');
  const emptyMsg = document.getElementById('cards-empty');

  function applyFilters() {
    const city = cityFilter.value;
    const sphere = sphereFilter.value;
    const type = typeFilter.value;
    let visible = 0;

    cards.forEach(card => {
      const matchCity = !city || card.dataset.city === city;
      const matchSphere = !sphere || card.dataset.sphere === sphere;
      const matchType = !type || card.dataset.type === type;
      const show = matchCity && matchSphere && matchType;
      card.style.display = show ? '' : 'none';
      if (show) visible++;
    });

    emptyMsg.hidden = visible > 0;
  }

  cityFilter.addEventListener('change', applyFilters);
  sphereFilter.addEventListener('change', applyFilters);
  typeFilter.addEventListener('change', applyFilters);

  resetBtn.addEventListener('click', () => {
    cityFilter.value = '';
    sphereFilter.value = '';
    typeFilter.value = '';
    applyFilters();
  });

  const regBtn = document.querySelector('.cta .btn--primary');
  if (regBtn) {
    regBtn.addEventListener('click', () => {
      const email = prompt('Введите ваш email для регистрации:');
      if (!email) return;

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        alert('Некорректный email. Попробуйте снова.');
        return;
      }

      alert(`Спасибо! Мы отправили письмо на ${email}`);
    });
  }
});